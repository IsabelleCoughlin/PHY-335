classdef FunctorD < NumericalRecipes.Functor
    % Abstract base class that is used to pass arbtrary
    % functions of a single variable 'x' and its first derivative
    % (and any associated  data), as arguments to other 
    % functions.   Based on the Abstract Functor class.
    methods
        % Creator method that creates an "instance" of the
        % class FunctorD.  Every class must have a Creator
        % method that initializes any 'properties' that the
        % class may poses.  In this case, the Creator does 
        % nothing but call the Functor creator.
        % "obj" is the actual instance (the class variable that 
        % takes up physical storage and defines the name
        % that will be used to refer to the object within the
        % class.
        function obj = FunctorD()
            obj = obj@NumericalRecipes.Functor();
        end
    end
    methods (Abstract)
        % 'Abstract' methods are used to define how a
        % particular method will work, but do not actually
        % have any code that implements them.
        %
        % In this case, the FunctorD class defines a single
        % method "df" that takes one arguement, 'x' and
        % returns a single value, 'val'.
        val = df(obj,x)
    end
end