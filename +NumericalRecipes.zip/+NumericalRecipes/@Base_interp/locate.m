function [ival,obj] = locate(obj,ix)
    % Given a value x, return a value i such that x is, insofar as
    % possible, centered int the subrange.  This method works well for
    % uncorrelated successive values of x.
    if (obj.n < 2) || (obj.mm < 2) || (obj.mm > obj.n)
        throw(MException('NumericalRecipes:Base_interp:locate','size error'));
    end
    ascnd = logical( obj.xx(obj.n) >= obj.xx(1) );
    jl = int16(1);
    ju = obj.n;
    while ju-jl > 1
        jm = int16( (ju+jl)/2 );
        if ((ix >= obj.xx(jm)) == ascnd)
            jl=jm;
        else
            ju=jm;
        end
    end
    if abs(jl-obj.jsav) > obj.dj
        obj.cor = false;
    else
        obj.cor = true;
    end
   obj. jsav = jl;
    ival = int16( max(1,min(obj.n-obj.mm+1,jl-int16(obj.mm-2)/2)) );
end