function [ival,obj] = hunt(obj,ix)
    % Given a value x, return a value i such that x is, insofar as
    % possible, centered int the subrange.  This method works well for
    % correlated successive values of x.
    jl = obj.jsav;
    inc =  int16(1);
    if (obj.n < 2) || (obj.mm < 2) || (obj.mm > obj.n)
        throw(MException('NumericalRecipes:Base_interp:hunt','size error'));
    end
    ascnd = logical( obj.xx(obj.n) >= obj.xx(1) );
    if (jl < 1) || (jl > obj.n)
        jl = int16(1);
        ju = obj.n;
    else
        if ((ix >= obj.xx(jl)) == ascnd)
            while true
                ju = jl + inc;
                if (ju >= obj.n)
                    ju = obj.n; 
                   break;
                else
                    if (ix < obj.xx(ju)) == ascnd
                        break;
                    else
                        jl = ju;
                        inc = inc+1;
                    end
                end
            end
        else
            ju = jl;
            while true
                jl = jl - inc;
                if (jl <= 1)
                    jl = 1;
                    break;
                else
                    if (ix >= obj.xx(jl)) == ascnd
                        break;
                    else
                        ju = jl;
                        inc = inc+1;
                    end
                end
            end
        end
    end
    while (ju-jl > 1)
        jm = int16( (ju+jl)/2 );
        if (ix >= obj.xx(jm)) == ascnd
            jl = jm;
        else
            ju = jm;
        end
    end
    if abs(jl - obj.jsav) > obj.dj
        obj.cor = false;
    else
        obj.cor = true;
    end
    obj.jsav = jl;
    ival = int16( max(1,min(obj.n-obj.mm+1,jl-int16(obj.mm-2)/2)) );
end