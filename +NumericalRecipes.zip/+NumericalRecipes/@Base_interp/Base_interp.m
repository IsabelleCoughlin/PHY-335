classdef Base_interp
    % Abstract base class used by interpolation routines.  
    %
    % Only the routine interp is called directly by the user.
    %
    % function y = interp(x)
    %
    properties (SetAccess = 'protected')
        jsav = int16(0);
        cor = false;
        n = int16(0);
        mm = int16(0);
        dj;
        xx, yy;
    end
    methods
        function obj = Base_interp(x,y,m)
            if nargin > 0
                obj.n = int16(length(x));
                obj.mm = int16(m);
                obj.xx = x;
                obj.yy = y;
            end
            obj.dj = int16( min(1,int16(double(obj.n)^0.25)) );
        end
        [ival,obj] = locate(obj, ix)
        [ival,obj] = hunt(obj, ix)
        function [ival,obj] = interp(obj, ix) 
            % Given a value of x, return an interpolated value.
            if obj.cor
                [jlo,obj] = obj.hunt(ix);
            else
                [jlo,obj] = obj.locate(ix);
            end
            [ival,obj] = obj.rawinterp(jlo,ix);
        end
    end
    methods (Abstract)
        [ival,obj] = rawinterp(obj,jlo,ix);
    end
end
        