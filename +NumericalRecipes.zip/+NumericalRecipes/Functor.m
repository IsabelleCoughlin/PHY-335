classdef Functor < handle
    % Abstract base class that is used to pass arbtrary
    % functions of a single variable 'x' (and any associated 
    % data) as arguments to other functions. 
    methods
        % Creator method that creates an "instance" of the
        % class Functor.  Every class must have a Creator
        % method that initializes any 'properties' that the
        % class may poses.  In this case, the Creator does 
        % nothing.
        % "obj" is the actual instance (the class variable that 
        % takes up physical storage and defines the name
        % that will be used to refer to the object within the
        % class.
        function obj = Functor()
        end
    end
    methods (Abstract)
        % 'Abstract' methods are used to define how a
        % particular method will work, but do not actually
        % have any code that implements them.
        %
        % In this case, the Functor class defines a single
        % method "func" that takes one arguement, 'x' and
        % returns a single value, 'val'.
        val = func(obj,x)
    end
end