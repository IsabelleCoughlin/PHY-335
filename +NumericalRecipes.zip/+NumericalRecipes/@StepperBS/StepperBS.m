classdef StepperBS < NumericalRecipes.StepperBase
    % Bulirsch-Stoer step with monitoring of local truncation error to
    % ensure accuracy and adjust stepsize.
    %
    properties
        KMAXX=8;
        IMAXX
        k_targ
        nseq
        cost
        table
        dydxnew
        mu
        coeff
        errfac
        ysave
        fsave
        ipoint
        dens
        initpers = true;
    end
    methods
        function obj = StepperBS(y,dydx,x,atol,rtol,density)
            if nargin == 0
                super_args = {};
            else
                super_args{1} = y;
                super_args{2} = dydx;
                super_args{3} = x;
                super_args{4} = atol;
                super_args{5} = rtol;
                super_args{6} = density;
            end
            obj = obj@NumericalRecipes.StepperBase(super_args{:});
            if nargin ~= 0, obj.init(super_args{:}); end
        end
        function init(obj,y,dydx,x,atol,rtol,dense)
                obj.x = x;
                obj.y = y;
                obj.dydx = dydx;
                obj.atol = atol;
                obj.rtol = rtol;
                obj.dense = dense;
                obj.n = length(y(1,:));
                obj.neqn = obj.n;
                obj.yout = zeros(1:obj.n);
                obj.yerr = zeros(1:obj.n);
                obj.IMAXX=obj.KMAXX+1;
                obj.nseq = zeros(obj.IMAXX,1,'int32');
                obj.cost = zeros(obj.IMAXX,1,'int32');
                obj.dydxnew = zeros(1:obj.n);
                obj.coeff = zeros(obj.IMAXX,obj.IMAXX);
                obj.errfac = zeros(2*obj.IMAXX+2,1);
                obj.ysave = zeros(obj.IMAXX,obj.n);
                obj.fsave = zeros(obj.IMAXX*(2*obj.IMAXX+1),obj.n);
                obj.ipoint = zeros(obj.IMAXX+1,1,'int32');
                obj.dens = zeros(1,(2*obj.IMAXX+5)*obj.n);
                obj.EPS = eps('double');
                if dense
                    for i=1:obj.IMAXX
                        obj.nseq(i)=4*i-2;
                    end
                else
                    for i=1:obj.IMAXX
                        obj.nseq(i)=2*i;
                    end
                end
                obj.cost(1) = obj.nseq(1)+1;
                for k=1:obj.KMAXX
                    obj.cost(k+1) = obj.cost(k)+obj.nseq(k+1);
                end
                obj.hnext = -1.0e99;
                logfact = -log10(max(1.e-12,rtol))*0.6 + 0.5;
                obj.k_targ=max(1,min(obj.KMAXX-1,floor(logfact)))+1;
                for k=1:obj.IMAXX
                    for l=1:obj.IMAXX
                        ratio = double(obj.nseq(k))/double(obj.nseq(l));
                        obj.coeff(k,l) = 1.0/(ratio*ratio-1.0);
                    end
                end
                for i=1:2*obj.IMAXX+1
                    ip4 = i+4;
                    obj.errfac(i) = 1.0/double(ip4*ip4);
                    e = 0.5*sqrt(double(i)/double(ip4));
                    for j=1:i
                        obj.errfac(i) = obj.errfac(i)*e/double(j);
                    end
                end
                obj.ipoint(1)=0;
                for i=2:obj.IMAXX+1
                    njadd = 4*i-6;
                    if obj.nseq(i-1) > njadd, njadd = njadd+1; end
                    obj.ipoint(i) = obj.ipoint(i-1) + njadd;
                end
        end
        [x, y, dydx] = step(obj,htry,derivs)
        [yend,ipt] = dy(obj,y,htot,k,ipt,derivs)
        [table,last] = polyextr(obj,k,table,last)
        error = prepare_dense(obj,h,dydxnew,ysav,scale,k)
        y = dense_out(obj,i,x,h)
    end
    methods(Static)
        y = dense_interp(n,y,imit)
    end
end