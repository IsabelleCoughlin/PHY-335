function[table,last] = polyextr(obj,k,table,last)
    for j=k-1:-1:2
        table(j-1,:) = table(j,:) + obj.coeff(k,j)*(table(j,:)-table(j-1,:));
    end
    last(1,:) = table(1,:) + obj.coeff(k,1)*(table(1,:) - last(1,:));
end