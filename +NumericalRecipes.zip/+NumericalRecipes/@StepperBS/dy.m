function [yend,ipt] = dy(obj,y,htot,k,ipt,derivs)
    nstep = obj.nseq(k);
    h = htot/double(nstep);
    ym = y;
    yn = ym + h*obj.dydx;
    xnew = obj.x + h;
    yend = derivs(xnew,yn);
    h2 = 2.0*h;
    for nn = 1:nstep-1
        if obj.dense && (nn == floor(nstep/2)), obj.ysave(k,:) = yn; end
        if obj.dense && (abs(nn - floor(nstep/2)) <= 2*k-1)
            ipt = ipt+1;
            obj.fsave(ipt,:) = yend;
        end
        swap = ym+h2*yend;
        ym = yn;
        yn = swap;
        xnew = xnew+h;
        yend = derivs(xnew,yn);
    end
    if obj.dense && (floor(nstep/2) <= 2*k-1)
        ipt = ipt+1;
        obj.fsave(ipt,:) = yend;
    end
    yend = 0.5*(ym + yn + h*yend);
end
