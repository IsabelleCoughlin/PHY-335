function yinterp = dense_out(obj,i,x,h)
    theta = (x - obj.xold)/h;
    theta1 = 1.0 - theta;
    yinterp = obj.dens(i) + theta*(obj.dens(obj.n+i)+theta1*(obj.dens(2*obj.n+i)* theta + obj.dens(3*obj.n+i)*theta1));
    if obj.mu <  0, return, end;
    theta05 = theta-0.5;
    t4 = (theta*theta1)^2;
    c = obj.dens(obj.n*(obj.mu+4)+i);
    for j=obj.mu:-1:1
        c = obj.dens(obj.n*(j+3)+i)+c*theta05/double(j);
    end
    yinterp = yinterp + t4*c;
end