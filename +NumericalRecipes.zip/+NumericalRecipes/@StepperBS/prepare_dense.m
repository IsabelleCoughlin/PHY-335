function error = prepare_dense(obj,h,dydxnew,ysav,scale,k)
    error = 0.0;
    obj.mu = 2*k-3;
    obj.dens(1:obj.n) = ysav;
    obj.dens(obj.n+1:2*obj.n) = h*obj.dydx;
    obj.dens(2*obj.n+1:3*obj.n) = obj.y;
    obj.dens(3*obj.n+1:4*obj.n) = h*dydxnew;
    for j=2:k %%%
        dblenj = double(obj.nseq(j));
        for l=j:-1:2
            factor = (dblenj/double(obj.nseq(l-1)))^2 - 1.0;
            obj.ysave(l-1,:) = obj.ysave(l,:) + (obj.ysave(l,:) - obj.ysave(l-1,:))/factor;
        end
    end
    obj.dens(4*obj.n+1:5*obj.n) = obj.ysave(1,:);
    for kmi=1:obj.mu
        kbeg = floor(double(kmi-1)/double(2)) + 1;
        for kk = kbeg:k %%%%
            facnj = (double(obj.nseq(kk))/2.0)^(kmi-1);
            ipt = obj.ipoint(kk+1)-2*kk+kmi;
            obj.ysave(kk,:)=obj.fsave(ipt,:)*facnj;
        end
        for j=kbeg+1:k %%%
            dblenj = double(obj.nseq(j));
            for l=j:-1:kbeg+1
                factor=(dblenj/double(obj.nseq(l-1)))^2-1.0;
                obj.ysave(l-1,:) = obj.ysave(l,:) + (obj.ysave(l,:)-obj.ysave(l,:))/factor;
            end
        end
        obj.dens((kmi+4)*obj.n+1:(kmi+5)*obj.n) = obj.ysave(kbeg,:)*h;
        if kmi == obj.mu, continue, end
        for kk=floor(double(kmi)/double(2))+1:k %%%
            lbeg = obj.ipoint(kk+1);
            lend = obj.ipoint(kk)+kmi+1;
            if kmi == 1, lend = lend+2; end
            for l=lbeg:-2:lend
                obj.fsave(l,:) = obj.fsave(l,:)-obj.fsave(l-2,:);
            end
            if kmi == 1
                l = lend-2;
                obj.fsave(l,:) = obj.fsave(l,:) - obj.dydx;
            end
        end
        for kk = floor(double(kmi)/double(2))+1:k %%%
            lbeg = obj.ipoint(kk+1)-1;
            lend = obj.ipoint(kk) + kmi + 2;
            for l=lbeg:-2:lend
                obj.fsave(l,:) = obj.fsave(l,:) - obj.fsave(l-2,:);
            end
        end
    end
    obj.dens = obj.dense_interp(obj.n,obj.dens,obj.mu);
    if obj.mu >= 1
        error = sum((obj.dens((obj.mu+4)*obj.n+1:(obj.mu+5)*obj.n)./scale(1,:)).^2);
        error = sqrt(error/double(obj.n))*obj.errfac(obj.mu);
    end
end