function y = dense_interp(n,y,imit)
    a = zeros(31,1);
    for i=1:n
        y0 = y(i);
        y1 = y(2*n+i);
        yp0 = y(n+i);
        yp1 = y(3*n+i);
        ydiff = y1-y0;
        aspl = -yp1+ydiff;
        bspl = yp0 - ydiff;
        y(n+i) = ydiff;
        y(2*n+i) = aspl;
        y(3*n+i) = bspl;
        if imit < 0, continue, end
        ph0 = (y0 + y1)*0.5 + 0.125*(aspl + bspl);
        ph1 = ydiff + (aspl - bspl)*0.25;
        ph2 = -(yp0-yp1);
        ph3 = 6.0*(bspl-aspl);
        if imit >= 1
            a(2) = 16.0*(y(5*n+i) - ph1);
            if imit >= 3
                a(4) = 16.0*(y(7*n+i) - ph3 + 3*a(2));
                for im = 5:2:imit
                    fac1 = double(im*(im-1))/2.0;
                    fac2 = fac1*(im-2)*(im-3)*2.0;
                    a(im+1)=16.0*(y((im+4)*n+i) + fac1*a(im-1) - fac2*a(im-3));
                end
            end
        end
        a(1) = (y(4*n+i)-ph0)*16.0;
        if imit >= 2
            a(3) = (y(n*6+i) - ph2 + a(1))*16.0;
            for im=4:2:imit
                fac1 = double(im*(im-1))/2.0;
                fac2 = im*(im-1)*(im-2)*(im-3);
                a(im+1) =  (y(n*(im+4)+i) + a(im-1)*fac1 - a(im-3)*fac2)*16.0;
            end
        end
        for im=0:imit
            y(n*(im+4)+i) = a(im+1);
        end
    end
end