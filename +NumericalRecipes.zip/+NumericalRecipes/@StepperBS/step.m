function [x, y, dydx] = step(obj,htry,derivs)
    STEPFAC1=0.65;
    STEPFAC2=0.94;
    STEPFAC3=0.03;
    STEPFAC4=4.0;
    KFAC1=0.8;
    KFAC2=0.9;
    persistent first_step last_step forward reject prev_reject
    if obj.initpers
        first_step=true;
        last_step=false;
        reject=false;
        prev_reject=false;
        obj.initpers=false;
    end
    hopt = zeros(obj.IMAXX,1);
    work = zeros(obj.IMAXX,1);
    scale = zeros(1,obj.n);
    work(1)=0.0;
    h = htry;
    if h > 0, forward=true; else forward=false; end
    ysav = obj.y;
    if (h ~= obj.hnext) && ~first_step, last_step = true; end
    if reject
        prev_reject = true;
        last_step = false;
    end
    reject = false;
    firstk = true;
    hnew = abs(h);
    while true
        while firstk || reject
            if forward, h = hnew; else h = -hnew; end
            firstk = false;
            reject = false;
            if abs(h) <= abs(obj.x)*obj.EPS
                throw(MException('NumericalRecipes:StepperBS','Stepsize underflow in step'));
            end
            ipt = 0;
            for k=1:obj.k_targ+2
                [yseq,ipt] = obj.dy(ysav,h,k,ipt,derivs);
                if k== 1
                    obj.y = yseq;
                else
                    obj.table(k-1,:) = yseq;
                end
                if k ~= 1
                    [obj.table,obj.y] = obj.polyextr(k,obj.table,obj.y);
                    scale = obj.atol + obj.rtol*max(abs(ysav),abs(obj.y));
                    err = sqrt(sum(((obj.y-obj.table(1,:))./scale).^2)/double(obj.n));
                    expo = 1.0/double(2*k-1);
                    facmin = STEPFAC3^expo;
                    if err == 0.0
                        fac = 1.0/facmin;
                    else
                        fac = STEPFAC2/(err/STEPFAC1)^expo;
                        fac = max(facmin/STEPFAC4,min(1.0/facmin,fac));
                    end
                    hopt(k) = abs(h*fac);
                    work(k) = double(obj.cost(k))/hopt(k);
                    if (first_step || last_step) && (err <= 1), break, end
                    if (k == obj.k_targ-1) && ~prev_reject && ~first_step && ~last_step
                        if err <= 1
                            break
                        elseif err > (obj.nseq(obj.k_targ)*obj.nseq(obj.k_targ+1)/double(obj.nseq(1)*obj.nseq(1)))^2;
                            reject = true;
                            obj.k_targ=k;
                            if (obj.k_targ > 2) && (work(k-1) < KFAC1*work(k))
                                obj.k_targ = obj.k_targ - 1;
                            end
                            hnew = hopt(obj.k_targ);
                            break
                        end
                    end
                    if k == obj.k_targ
                        if err <= 1.0
                            break
                        elseif err > (double(obj.nseq(k+1))/double(obj.nseq(1)))^2
                            reject = true;
                            if (obj.k_targ > 2) && (work(k-1) < KFAC1*work(k))
                                obj.k_targ = obj.k_targ - 1;
                            end
                            hnew = hopt(obj.k_targ);
                            break
                        end
                    end
                    if k == obj.k_targ+1
                        if err > 1.0
                            reject = true;
                            if (obj.k_targ > 2) && (work(k-1) < KFAC1*work(obj.k_targ))
                                obj.k_targ = obj.k_targ - 1;
                            end
                            hnew = hopt(obj.k_targ);
                        end
                        break
                    end
                end
            end
            if reject, prev_reject = true; end
        end
        obj.dydxnew = derivs(obj.x + h, obj.y);
        if obj.dense
            err = obj.prepare_dense(h,obj.dydxnew,ysav,scale,k);
            hopt_int = h/max(err^(1.0/double(2*k+1)),0.01);
            if err > 10.0
                hnew = abs(hopt_int);
                reject = true;
                prev_reject = true;
                continue
            end
        end
        break
    end
    obj.dydx = obj.dydxnew;
    dydx = obj.dydx;
    obj.xold = obj.x;
    obj.x = obj.x + h;
    x = obj.x;
    obj.hdid = h;
    y = obj.y;
    first_step = false;
    if k == 2
        kopt = 3;
    elseif k <= obj.k_targ
        kopt = k;
        if work(k-1) < KFAC1*work(k)
            kopt = k-1;
        elseif work(k) < KFAC2*work(k-1)
            kopt = min(k+1,obj.KMAXX);
        end
    else
        kopt = k-1;
        if (k > 3) && (work(k-2) < KFAC1*work(k-1)), kopt = k-2; end
        if work(k) < KFAC2*work(kopt), kopt = min(k,obj.KMAXX); end
    end
    if prev_reject
        obj.k_targ = min(kopt,k);
        hnew = min(abs(h),hopt(obj.k_targ));
        prev_reject=false;
    else
        if kopt <= k
            hnew = hopt(kopt);
        else
            if (k<obj.k_targ) && (work(k) < KFAC2*work(k-1))
                hnew = hopt(k)*double(obj.cost(kopt+1))/double(obj.cost(k));
            else
                hnew = hopt(k)*double(obj.cost(kopt))/double(obj.cost(k));
            end
        end
        obj.k_targ = kopt;
    end
    if obj.dense, hnew = min(hnew,abs(hopt_int)); end
    if forward
        obj.hnext = hnew;
    else
        obj.hnext = -hnew;
    end
end
    
