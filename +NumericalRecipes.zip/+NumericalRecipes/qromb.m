function integral = qromb(func,a,b,varargin)
    % Returns the integral of func on the interval between a and b
    % using Romberg integration
    %
    % INPUT
    % func is the function to be integrated.  It can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle.  a and b are
    % the lower and upper limits of integration.  A single optional
    % argument is the fractional accuracy (defaults to 1.e-10).
    % OUTPUT
    % The integral of the given function.
    %     
    eps = 1.0e-10;
    if size(varargin,2) == 1
        eps = varargin{1};
    else
        if size(varargin,2) > 1
            throw(MException('NumericalRecipes:qromb','Too many inputs'));
        end
    end
    jmax = int16(20);
    jmaxp = jmax+1;
    K = int16(5);
    s = zeros(jmax,1);
    h = ones(jmaxp,1);
    t = NumericalRecipes.Trapzd(func,a,b);
    for j=1:jmax
        [s(j),t] = t.next();
        if j >= K
            polint = NumericalRecipes.Poly_interp(h,s,K);
            [ss,polint] = polint.rawinterp(j-K+1,0.0);
            if abs(polint.dy) <= eps*abs(ss)
                integral = ss;
                return
            end
        end
        h(j+1) = 0.25*h(j);
    end
    throw(MException('NumericalRecipes:qromb','Too many iterations'));
end