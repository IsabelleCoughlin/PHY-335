classdef Cholesky
    % Class for Cholesky decomposition of a matrix A and related functions.
    % A must be a positive-definite symmetric matrix.
    %
    % Construct with the matrix A
    %         Cholesky_obj = NumericalRecipes.Cholesky(A);
    %
    % Methods:
    %
    % Cholesky_obj.solve(b) : 
    % Solves the set of n linear equations A*x=b using the stored Cholesky
    % decomposition of A.  b can be either a column vector or a matrix
    % containing a set of "k" column vectors.  It returns either a column
    % vector or a matrix containing a set of "k" column vectors
    % representing the solution "x".
    %
    % Cholesky_obj.elmult(x) : 
    % Multiply L*x=b where L is the lower triangular matrix in the stored
    % Cholesky decomposition of A.  x can be either a column vector or a
    % matrix containing a set of "k" column vectors.  It returns either a
    % column vector or a matrix containing a set of "k" column vectors
    % representing the product "b".
    %
    % Cholesky_obj.elsolve(b) : 
    % Solves L*x=b where L is the lower triangular matrix in the stored
    % Cholesky decomposition of A.  b can be either a column vector or a
    % matrix containing a set of "k" column vectors.  It returns either a
    % column vector or a matrix containing a set of "k" column vectors
    % representing the solution "x".
    %
    % Cholesky_obj.inverse() :
    % Returns the matrix inverse of A.
    %
    % Cholesky_obj.logdet() :
    % Returns the logarithm of the determinant of A.
    %
    properties
        el
        optl
        optt
    end
    methods
        function obj = Cholesky(A)
            obj.el = chol(A,'lower');
            obj.optl.LT = true;
            obj.optt.LT = true;
            obj.optt.TRANSA = true;
        end
        function x = solve(obj,b)
            x = linsolve(obj.el,b,obj.optl);
            x = linsolve(obj.el,x,obj.optt);
        end
        function b = elmult(obj,x)
            b = obj.el*x;
        end
        function y = elsolve(obj,b)
            y = linsolve(obj.el,b,obj.optl);
        end
        function inv = inverse(obj)
            inv = linsolve(obj.el,eye(size(obj.el)),obj.optl);
            inv = linsolve(obj.el,inv,obj.optt);
        end
        function d = logdet(obj)
            d = 2.0*sum(log(diag(obj.el)));
        end
    end
end