function val = qgaus(func,a,b)
    % Returns the integral of func on the interval between a and b
    % using 10-point Gauss-Legendre integration.
    %
    % INPUT
    % func is the function to be integrated.  It can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle.  a and b are
    % the lower and upper limits of integration. 
    % OUTPUT
    % The integral of the given function.
    %     
    x = [0.1488743389816312 0.4333953941292472 0.6794095682990244 0.8650633666889845 0.9739065285171717];
    w = [0.2955242247147529 0.2692667193099963 0.2190863625159821 0.1494513491505806 0.0666713443086881];
    xm = 0.5*(b+a);
    xr = 0.5*(b-a);
    val = 0;
    for j=1:5
        dx = xr*x(j);
        val = val + w(j)*(func(xm + dx) + func(xm - dx));
    end
    val = val*xr;
end