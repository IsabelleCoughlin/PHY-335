classdef Shootf < NumericalRecipes.Functor
    % Functor for use with "newt" to solve a two-point boundary value
    % problem for a set of ODEs by shooting to a "fitting point". 
    % The coupled ODEs are integrated from x1 to xf with initial values for
    % the ODE variables supplied at x1, and from x2 to xf with initial
    % values for the ODE variables supplied at x2. Some number of initial
    % values, n1, are known at x1, while n2 values are known at x2, and
    % n1+n2 is the total number of coupled ODEs.  The initial values at x1
    % are constructed based on the n1 known values and n2 parameters which
    % must be determined.  The initial values at x2 are constructed based
    % on the n2 known values and n1 parameters which must be determined.
    % The load1 and load2 objects will be passed the same vector of
    % coefficients which contains all n1+n2 coefficients.
    %
    % Construct with the two starting points and fitting points, a class
    % derived from NumericalRecipes.FunctorShoot to load initial values for
    % each of the starting points, a class derived from
    % NumericalRecipes.FunctorODE to supply the set of ODEs to be
    % integrated, and a class derived from NumericalRecipes.FunctorShoot 
    % to return a vector of scores which should match at the fitting
    % point xf.  The score can simply be the integrated function values,
    % meaning that the integrated functions must agree at the fitting
    % point.  However using score profides the flexibility of comparing
    % n1+n2 specifiable functions of the integrated functions at the
    % fitting point.  The difference between the scores evaluated from 
    % the two integrations should be zero when the solution is found.
    %
    %    x1 = first start point of integration;
    %    x2 = second start point of integration;
    %    xf = end point of integration (between x1 and x2);
    %    load1_obj = NumericalRecipes.FunctorShoot_obj(...);
    %    load2_obj = NumericalRecipes.FunctorShoot_obj(...);
    %    derivs_obj = NumericalRecipes.FunctorODE_obj(...);
    %    score_obj = NumericalRecipes.FunctorShoot_obj(...);
    %    Shootf_obj =
    %            NumericalRecipes.Shoot(x1,x2,load1_obj,load2_obj,
    %                                            derivs_obj,score_obj)
    %
    % The Shootf object is passed to NumercialRecipes.newt as the vecfunc
    % argument.
    %
    properties
        atol = 1.e-8;
        rtol = 1.e-8;
        hmin = 0.0;
        x1
        x2
        xf
        load1
        load2
        d
        score
    end
    methods
        function obj = Shootf(x1,x2,xf,load1,load2,derivs,score)
            obj.x1 = x1;
            obj.x2 = x2;
            obj.xf = xf;
            obj.load1 = @load1.vector;
            obj.load2 = @load2.vector;
            obj.d = derivs;
            obj.score = @score.vector;
        end
        function derivs = func(obj,v)
            h1 = (obj.x2 - obj.x1)/100.0;
            y = obj.load1(obj.x1,v);
            out = NumericalRecipes.Output(0);
            integ1 = NumericalRecipes.Odeint(NumericalRecipes.StepperDopr5(),y,obj.x1,obj.xf,obj.atol,obj.rtol,h1,obj.hmin,out,obj.d);
            y = integ1.integrate();
            f1 = obj.score(obj.xf,y);
            y = obj.load2(obj.x1,v);
            integ2 = NumericalRecipes.Odeint(NumericalRecipes.StepperDopr5(),y,obj.x2,obj.xf,obj.atol,obj.rtol,h1,obj.hmin,out,obj.d);
            y = integ2.integrate();
            f2 = obj.score(obj.xf,y);
            derivs = f1 - f2;
        end
    end
end