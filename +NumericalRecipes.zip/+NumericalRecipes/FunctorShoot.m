classdef FunctorShoot < handle
    % Abstract base class that is used to pass "load" and "score"
    % functions to Shoot and Shootf. 
    methods (Abstract)
        % 'Abstract' methods are used to define how a
        % particular method will work, but do not actually
        % have any code that implements them.
        %
        % In this case, the FunctorShoot class defines a single
        % method "vector" that takes two arguements, a position 'x' and
        % a vector 'v', then returns a vector.
        % In the case of a "load" function, the vector v contains the free
        % parameters in the initial boundary conditions at x, and returns
        % a vector containing all of the initial values of the ODE
        % variables.
        % In the case of a "score" function, the vector v contains the
        % values of the ODE variables at the end of the integration and
        % returns either 1) a vector containing the discrepecy of the 
        % ending boundary conditions when used with Shoot, or 2) a 
        % vector of function values when used with Shootf.
        % NOTE: the vector returned by "score" must be a column vector.
        vec = vector(obj,x,v)
    end
end