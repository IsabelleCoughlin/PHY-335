classdef Linear_interp < NumericalRecipes.Base_interp
    % Linear interpolation object.  
    %
    % Construct with x and y vectors, then call interp for interpolated 
    % values.
    % 
    % interp_object = NumericalRecipes.Linear_interp(x,y)
    %
    % function y = interp_object.interp(x)
    %               x : must be a single double precision number. Vectors
    %                   are not allowed.
    %               y : a single double precision number containing the
    %                   interpolated function value at x.
    %
    methods
        function obj = Linear_interp(x,y)
            if nargin > 0
                super_args{1} = x;
                super_args{2} = y;
                super_args{3} = 2;
            else
                super_args = {};
            end
           obj = obj@NumericalRecipes.Base_interp(super_args{:});
        end
        %
        function [ival,obj] = rawinterp(obj,jl,ix)
            % Given a value of x, this routing returns an interpolated
            % value y. 
            if obj.xx(jl) == obj.xx(jl+1)
                ival = obj.yy(jl);
            else
                ival = obj.yy(jl) ...
                    + ((ix-obj.xx(jl))/(obj.xx(jl+1)-obj.xx(jl))) ...
                    *(obj.yy(jl+1)-obj.yy(jl));
            end
        end
    end
end
    