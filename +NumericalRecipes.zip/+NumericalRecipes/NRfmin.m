classdef NRfmin < handle
    % Utility class that computes 1/2 F.F
    %
    % Construct with a vector function func that can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle. 
    %
    properties
        funcc
        fvec
    end
    methods
        function obj = NRfmin(func)
            if strcmp(class(func),'function_handle')
                obj.funcc = func;
            else
                if isa(func,'NumericalRecipes.Functor')
                    obj.funcc = @ func.func;
                else
                    throw(MException('NumericalRecipes:NRfmin','No Function or Functor'));
                end
            end
        end
        function val = func(obj,x)
            obj.fvec = obj.funcc(x);
            val = 0.5*sum(obj.fvec.^2);
        end
    end
end