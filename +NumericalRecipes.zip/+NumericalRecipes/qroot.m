function [b,c] = qroot(p,b,c,eps)
    % Find a quadratic factor of a polynomial.
    %
    % Use Bairstow's method to find a real quadratic factor x^2 + b*x + c
    % of a real polynomial.
    % INPUT
    % p is a vector of real coefficients of the polynomial
    %       Sum(i=0,m; p(i+1)x^i)
    % b and c are initial guesses for the coefficients of the quadratic.
    % eps is the desired uncertainty in b and c
    % OUTPUT
    % b and c contain the refined coefficients of the quadratic.
    % 
    ITMAX=20;
    TINY=1.0e-12;
    d = zeros(3,1);
    d(3)=1.0;
    for iter=1:ITMAX
        d(2) = b;
        d(1) = c;
        [q,rem] = NumericalRecipes.poldiv(p,d);
        s = rem(1);
        r = rem(2);
        [qq,rem] = NumericalRecipes.poldiv(q,d);
        sc = -rem(1);
        rc = -rem(2);
        sb = -c*rc;
        rb = sc - b*rc;
        div = 1.0/(sb*rc - sc*rb);
        delb = (r*sc - s*rc)*div;
        delc = (-r*sb + s*rb)*div;
        b = b + delb;
        c = c + delc;
        if ((abs(delb) <= eps*abs(b)) || (abs(b) < TINY)) && ((abs(delc) < eps*abs(c)) || (abs(c) < TINY))
            return
        end
    end
    throw(MException('NumericalRecipes:qroot','too many iterations'));
end