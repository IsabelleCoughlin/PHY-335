classdef Trapzd < NumericalRecipes.Quadrature
    % Class implementing the extended trapezoidal rule.
    %
    % Construct with the function to be integrated and the limits of
    % integration.  The function can either be a MATLAB function handle
    % or a NumericalRecipes 'Functor'.  Successive calls to next return
    % increasingly refined results for the integral.
    %
    %  int_class = NumercialRecipes.Trapzd(@(x) f(x),a,b); % Anonymous f(x)
    %         or = NumercialRecipes.Trapzd(@func,a,b);
    %         or = NumercialRecipes.Trapzd(Functor,a,b);
    %     
    properties
        func
        a
        b
        s
    end
    methods
        function obj = Trapzd(funcc,aa,bb)
            obj = obj@NumericalRecipes.Quadrature();
            if nargin > 0
                if strcmp(class(funcc),'function_handle')
                    obj.func = funcc;
                else
                    if isa(funcc,'NumericalRecipes.Functor')
                        obj.func = @ funcc.func;
                    else
                        throw(MException('NumericalRecipes:Trapzd','No Function or Functor'));
                    end
                end
                obj.a = aa;
                obj.b = bb;
                obj.s = 0;
            end
        end
        function [val,obj] = next(obj)
            obj.n = obj.n + 1;
            if obj.n == 1
                obj.s = 0.5*(obj.b - obj.a)*(obj.func(obj.a) +obj. func(obj.b));
                val = obj.s;
            else
                it = int32(1);
                for j=1:obj.n-2
                    it = 2*it;
                end
                tnm =double(it);
                del = (obj.b - obj.a)/tnm;
                x = obj.a + 0.5*del;
                sum = 0;
                for j=0:it-1
                    sum = sum +obj.func(x);
                    x = x + del;
                end
                obj.s = 0.5*(obj.s + (obj.b - obj.a)*sum/tnm);
                val = obj.s;
            end
        end
    end
end