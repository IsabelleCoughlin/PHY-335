classdef Midpnt < NumericalRecipes.Quadrature
    % Class implementing the extended midpoint rule.
    %
    % Construct with the function to be integrated and the limits of
    % integration.  The function can either be a MATLAB function handle
    % or a NumericalRecipes 'Functor'.  Successive calls to next return
    % increasingly refined results for the integral.
    %
    %  int_class = NumercialRecipes.Midpnt(@(x) f(x),a,b); % Anonymous f(x)
    %         or = NumercialRecipes.Midpnt(@func,a,b);
    %         or = NumercialRecipes.Midpnt(Functor,a,b);
    %     
    properties
        funk
        a
        b
        s
    end
    methods
        function obj = Midpnt(funcc,aa,bb)
            obj = obj@NumericalRecipes.Quadrature();
            if nargin > 0
                if strcmp(class(funcc),'function_handle')
                    obj.funk = funcc;
                elseif isa(funcc,'NumericalRecipes.Functor')
                    obj.funk = @ funcc.func;
                else
                    throw(MException('NumericalRecipes:Midpnt','No Function or Functor'));
                end
                obj.a = aa;
                obj.b = bb;
                obj.s = 0;
            end
        end
        function [val,obj] = next(obj)
            obj.n = obj.n + 1;
            if obj.n == 1
                obj.s = (obj.b - obj.a)*(obj.func(0.5*(obj.a + obj.b)));
                val = obj.s;
            else
                it = int32(1);
                for j=1:obj.n-2
                    it = 3*it;
                end
                tnm =double(it);
                del = (obj.b - obj.a)/(3.0*tnm);
                ddel = del + del;
                x = obj.a + 0.5*del;
                sum = 0;
                for j=0:it-1
                    sum = sum + obj.func(x);
                    x = x + ddel;
                    sum = sum + obj.func(x);
                    x = x + del;
                end
                obj.s = (obj.s + (obj.b - obj.a)*sum/tnm)/3.0;
                val = obj.s;
            end
        end
        function val = func(obj,x)
            val = obj.funk(x);
        end
    end
end