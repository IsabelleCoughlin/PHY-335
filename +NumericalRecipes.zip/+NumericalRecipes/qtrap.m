function integral = qtrap(func,a,b,varargin)
    % Returns the integral of func on the interval between a and b
    % using the trapezoidal rule
    %
    % INPUT
    % func is the function to be integrated.  It can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle.  a and b are
    % the lower and upper limits of integration.  A single optional
    % argument is the fractional accuracy (defaults to 1.e-10).
    % OUTPUT
    % The integral of the given function.
    %     
    eps = 1.0e-10;
    if size(varargin,2) == 1
        eps = varargin{1};
    else
        if size(varargin,2) > 1
            throw(MException('NumericalRecipes:qtrap','Too many inputs'));
        end
    end
    jmax = int16(20);
    s = 0.0;
    olds = s;
    t = NumericalRecipes.Trapzd(func,a,b);
    for j=1:jmax
        [s,t] = t.next();
        if j >= 5
            if (abs(s - olds) < eps*abs(olds)) || (s == 0.0 && olds == 0.0)
                integral = s;
                return
            end
        end
        olds = s;
    end
    throw(MException('NumericalRecipes:qtrap','Too many iterations'));
end