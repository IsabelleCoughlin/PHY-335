function [xb1,xb2]= zbrak(funcc,x1,x2,n)
    % Attempt to find a set of brackets for roots of a given function.
    %
    % Given a function funcc and an interval x1..x2, subdivide the interval
    % into n equally spaced segements and search for zero crossings within
    % each interval.
    % INPUT
    % funcc is the function to be tested.  It can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle.  x1 and x2
    % are the interval and n is the number of equally spaced intervals into
    % which the initial interval is divided.
    % OUTPUT
    % xb1 and xb2 are vectors containing, respectively, the lower and upper
    % bounds of each bracketed root.  The number of bracketed roots is
    % equal to length(xb1)
    % 
    nroot = 1;
    xb1=[]; xb2=[];
    if strcmp(class(funcc),'function_handle')
        fx = funcc;
    elseif isa(funcc,'NumericalRecipes.Functor')
        fx = @ funcc.func;
    else
        throw(MException('NumericalRecipes:zbrak','No Function or Functor'));
    end
    dx = (x2 - x1)/n;
    x = x1;
    fp = fx(x1);
    for i=1:n
        x = x + dx;
        fc = fx(x);
        if fc*fp <= 0.0
            xb1(nroot) = x-dx;
            xb2(nroot) = x;
            nroot = nroot+1;
        end
        fp = fc;
    end
end
        
    