classdef QRdcmp
    % Class for QR decomposition of a matrix A and related functions.
    %
    % Construct with the matrix A
    %         QR_obj = NumericalRecipes.QRdcmp(A);
    %
    % Methods:
    %
    % QR_obj.solve(b) : 
    % Solves the set of n linear equations A*x=b using the stored Cholesky
    % decomposition of A.  b can be either a column vector or a matrix
    % containing a set of "k" column vectors.  It returns either a column
    % vector or a matrix containing a set of "k" column vectors
    % representing the solution "x".
    %
    % QR_obj.qtmult(b) : 
    % Multiply transpose(L)*b=x where Q is the orthogonal matrix in the
    % stored QR decomposition of A. Since Q is orthogonal, this is
    % equivalent to solving Q*x=b.  b can be either a column vector or a 
    % matrix containing a set of "k" column vectors.  It returns either a
    % column vector or a matrix containing a set of "k" column vectors
    % representing the product "x".
    %
    % QR_obj.rsolve(b) : 
    % Solves R*x=b where R is the upper triangular matrix in the stored
    % QR decomposition of A.  b can be either a column vector or a matrix
    % containing a set of "k" column vectors.  It returns either a column
    % vector or a matrix containing a set of "k" column vectors
    % representing the solution "x". 
    %
    % QR_obj.update(u,v) :
    % Starting from the stored QR decomposition A=Q*R, update it to be the
    % QR decomposition of the matrix Q*(R + outerprod(u,v)) where u and v
    % are vectors.
    %
    properties
        qt
        r
        sing = false;
        optu
    end
    methods
        function obj = QRdcmp(A)
            [obj.qt,obj.r] = qr(A);
            obj.qt = obj.qt';  % save the transpose of Q
            n = size(A);
            for k=1:n
                if max(0.0,max(abs(A(k:n,k)))) == 0.0, obj.sing = true; end
            end
            obj.optu.UT = true;
        end
        function x = qtmult(obj,b)
            x = obj.qt*b;
        end
        function x = rsolve(obj,b)
            x = linsolve(obj.r,b,obj.optu);
        end
        function x = solve(obj,b)
            x = linsolve(obj.r,obj.qt*b,obj.optu);
        end
        function obj = update(obj,u,v)
            [tmp,obj.r] = qrupdate(obj.qt,obj.r,obj.qt'*u,v);
        end
    end
end