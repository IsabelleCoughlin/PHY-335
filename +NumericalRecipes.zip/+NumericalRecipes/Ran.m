classdef Ran < handle
    % Class to handle generation of random numbers.
    %
    % Constuctor is called with an integer seed.
    %	rand_obj = NumericalRecipes.Ran(seed);
    % Usage:
    %   rand_obj.doub() returns a random double precission number in the
    %   range (0,1).
    %   rand_obj.int32() returns a random unsigned 32-bit integer
    %   rand_obj.int64() returns a random unsigned 64-bit integer
    %
    properties
        s
        im32 = intmax('uint32');
        im64 = intmax('uint64');
    end
    methods
        function obj = Ran(j)
            obj.s = RandStream('mt19937ar','Seed',j);
        end
        function d = doub(obj)
            d = rand(obj.s);
        end
        function i = int32(obj)
            i = obj.im32*rand(obj.s);
        end
        function i = int64(obj)
            i = obj.im64*rand(obj.s);
        end
    end
end