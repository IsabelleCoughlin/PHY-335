function [x,check] = broydn(x,vecfunc)
    % Use Broyden's method to find the root of a vector of functions in
    % n-dim space. 
    %
    % Given an initial guess for a root in n dimensions, find the root by
    % Broyden's method embedded in a globally convergent strategy.
    % INPUT
    % x is a vector containing the n-dimension initial guess for a root.
    % vecfunc is a vector of function of the n-dim position vector. It can
    % be either a NumericalRecipes 'Functor', or a MATLAB function handle.
    % OUTPUT
    % x is a vector containing the n-dimensional root.  check is a boolean
    % which is False on a normal return and True if the function has
    % converged to a local minimum.
    %
    MAXITS = int16(200);
    EPS = eps('double');
    TOLF = 1.e-8; TOLX = EPS; STPMX = 100.0; TOLMIN = 1.e-12;
    n = length(x);
    xold = zeros(n,1);
    fvcold = zeros(n,1);
    nrfmin = NumericalRecipes.NRfmin(vecfunc);
    fmin = @nrfmin.func;
    nrfdjac = NumericalRecipes.NRfdjac(vecfunc);
    fdjac = @nrfdjac.func;
    f = fmin(x);
    test = max(0.0,max(abs(nrfmin.fvec)));
    if test < 0.01*TOLF; check = false; return, end
    bsum = sum(x.^2);
    stpmax = STPMX*max(sqrt(bsum),double(n));
    restart = true;
    for its=1:MAXITS
        if restart
            qr = NumericalRecipes.QRdcmp(fdjac(x,nrfmin.fvec));
            if qr.sing, qr = NumericalRecipes.QRdcmp(eye(n)); end
        else
            s(:,1) = x - xold;
            t = qr.r*s;
            skip = true;
            w = nrfmin.fvec - fvcold - (qr.qt')*t;
            for i=1:n
                if abs(w(i)) >= EPS*(abs(nrfmin.fvec(i)) + abs(fvcold(i)))
                    skip = false;
                else
                    w(i) = 0.0;
                end
            end
            if ~skip
                t = qr.qtmult(w);
                den = sum(s.^2);
                s = s./den;
                qr = qr.update(t,s);
                if qr.sing
                    throw(MException('NumericalRecipes:broydn','singular update'));
                end
            end
        end
        p = -qr.qtmult(nrfmin.fvec);
        g = -(qr.r')*p;
        xold = x;
        fvcold = nrfmin.fvec;
        fold = f;
        p = qr.rsolve(p);
        slope = g'*p;
        if slope >= 0.0
            restart = true;
            continue
        end
        [x,f,check] = NumericalRecipes.lnsrch(xold,fold,g,p,stpmax,fmin);
        test = max(0.0,max(abs(nrfmin.fvec)));
        if test < TOLF
            check = false;
            return
        end
        if check
            if restart
                return
            else
                test = 0.0;
                den = max(f,0.5*double(n));
                for i=1:n
                    temp = abs(g(i))*max(abs(x(i)),1.0)/den;
                    if temp > test, test = temp; end
                end
                if test < TOLMIN
                    return;
                else
                    restart = true;
                end
            end
        else
            restart = false;
            test = 0.0;
            for i=1:n
                temp = (abs(x(i) - xold(i)))/max(abs(x(i)),1.0);
                if temp > test, test = temp; end
            end
            if test < TOLX, return, end
        end
    end
    throw(MException('NumericalRecipes:broydn','MAXITS exceeded'));
end