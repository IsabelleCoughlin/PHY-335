function [ival,obj] = rawinterp(obj,jl,ix)
    % Given a value of x, this routing returns an interpolated value y and
    % stores an error estimate in dy.
    ns = int16(1);
    c = zeros(obj.mm,1);
    d = zeros(obj.mm,1);
    dif = abs(ix - obj.xx(jl));
    for i=1:obj.mm
        dift = abs(ix - obj.xx(i+jl-1));
        if dift < dif
            ns=i;
            dif=dift;
        end
        c(i) = obj.yy(i+jl-1);
        d(i) = c(i);
    end
    ival = obj.yy(ns+jl-1);
    ns = ns-1;
    for m=1:obj.mm-1
        for i=1:obj.mm-m
            ho = obj.xx(i+jl-1)-ix;
            hp = obj.xx(i+jl-1+m)-ix;
            w = c(i+1)-d(i);
            den = ho - hp;
            if den == 0.0
                throw(MException('NumericalRecipes:Poly_interp:rawinterp','x values too close'));
            end
            den = w/den;
            d(i) = hp*den;
            c(i) = ho*den;
        end
        if (2*ns) < (obj.mm-m)
            obj.dy = c(ns+1);
        else
            obj.dy = d(ns);
            ns = ns-1;
        end
        ival = ival+obj.dy;
    end   
end