classdef Midinf < NumericalRecipes.Midpnt
    % Class implementing the extended midpoint rule.
    % This routine is an exact replacement for Midpnt except that the
    % function is evaluated at evenly spaced points in 1/x rather than x.
    % This allows the upper limit bb to be as large and positive as the
    % computer allows, or the lower limit aa to be as large and negative,
    % but not both.  aa and bb must have the same sign.
    %
    % Construct with the function to be integrated and the limits of
    % integration.  The function can either be a MATLAB function handle
    % or a NumericalRecipes 'Functor'.  Successive calls to next return
    % increasingly refined results for the integral.
    %
    %  int_class = NumercialRecipes.Midpnt(@(x) f(x),a,b); % Anonymous f(x)
    %         or = NumercialRecipes.Midpnt(@func,a,b);
    %         or = NumercialRecipes.Midpnt(Functor,a,b);
    %     
    methods
        function obj = Midinf(funcc,aa,bb)
            obj = obj@NumericalRecipes.Midpnt(funcc,1/bb,1/aa);
        end
        function val = func(obj,x)
            val = obj.funk(1.0/x)/(x*x);
        end
    end
end