
function r = BlockTridag(a,b,c,r)
    % Solve a "Block" Tridiagonal system of equations.
    %
    % The Matrix consists of m-by-m blocks with n blocks along the
    % diagonal, so that the  the full matrix is (m*n)-by-(m*n)
    % The only non-zero elements are the block lower diagonal
    % stored in "a", the block diagonal store in "b", and the block
    % upper diagonal stored in "c".  The right-hand side is stored in
    % the vector "r".
    % INPUT
    %  a,b, and c are  arrays of dimension(m,m,n), and r is an array
    % of dimension(m,n).  The elements a(:,:,1) and c(:,:,n) are not
    % used.
    % OUTPUT
    % The result of solving the system of equations is returned and
    % has the same dimensions as "r".
    %
    [m,n] = size(r);
    beta = b(:,:,1);
    r(:,1) = beta\r(:,1);
    for j=2:n
        b(:,:,j-1) = beta\c(:,:,j-1);
        beta = b(:,:,j) - a(:,:,j)*b(:,:,j-1);
        r(:,j) = beta\(r(:,j) - a(:,:,j)*r(:,j-1));
    end
    for j=n-1:-1:1
        r(:,j) = r(:,j) - b(:,:,j)*r(:,j+1);
    end
end