classdef StepperBase < handle
    % Abstract base class for implementing ODE stepping algorithms
    %
    properties
        x
        xold
        y
        dydx
        atol
        rtol
        dense = false;
        hdid
        hnext
        EPS
        n
        neqn
        yout
        yerr
    end
    methods
        function obj = StepperBase(y,dydx,x,atol,rtol,dense)
            if nargin ~= 0
                obj.x = x;
                obj.y = y;
                obj.dydx = dydx;
                obj.atol = atol;
                obj.rtol = rtol;
                obj.dense = dense;
                obj.n = length(y(1,:));
                obj.neqn = obj.n;
                obj.yout = zeros(1:obj.n);
                obj.yerr = zeros(1:obj.n);
            end
        end
    end
    methods (Abstract)
        init(obj,y,dydx,x,atol,rtol,dense)
        [x, y, dydx] = step(obj,htry,derivs)
    end
end