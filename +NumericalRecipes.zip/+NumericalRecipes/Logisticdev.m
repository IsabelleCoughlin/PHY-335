classdef Logisticdev < NumericalRecipes.Ran
    % Class implementing Logistic deviates
    %
    % Construct with gaussian parameters mu, sig, and a seed
    %   rand_obj = NumericalRecipes.Logisticdev(mu,sig,seed)
    % Usage:
    %   rand_obj.dev() returns a random double precission number that is a
    %   random deviate from the Logistic distribution 
    %         pi/(4*sqrt(3)*sig)*sech^2(pi/(2*sqrt(3))*(x-mu)/sig))
    %
    properties
        mu
        sig
    end
    methods
        function obj = Logisticdev(mu,sig,i)
            obj = obj@NumericalRecipes.Ran(i);
            obj.mu = mu;
            obj.sig = sig;
        end
        function val = dev(obj)
            u = obj.doub();
            while (u*(1.0-u)) == 0
                u = obj.doub();
            end
            val = obj.mu + 0.551328895421792050*obj.sig*log(u/(1.0-u));
        end
    end
end