classdef Expodev < NumericalRecipes.Ran
    % Class implementing exponential deviates
    %
    % Construct with the exponential weight beta and seed
    %   rand_obj = NumericalRecipes.Expodev(beta,seed)
    % Usage:
    %   rand_obj.dev() returns a random double precission number that is a
    %   random deviate from the exponential distribution 
    %               beta * exp(-beta * y) for y>=0.
    %
    properties
        beta
    end
    methods
        function obj = Expodev(beta,i)
            obj = obj@NumericalRecipes.Ran(i);
            obj.beta = beta;
        end
        function val = dev(obj)
            u = obj.doub();
            while u == 0
                u = obj.doub();
            end
            val = -log(u)/obj.beta;
        end
    end
end