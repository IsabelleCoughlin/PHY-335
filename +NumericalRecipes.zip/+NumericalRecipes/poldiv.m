function [q,r] = poldiv(u,v)
    % Divide one polynomial by another, finding the quotient and remainder.
    %
    % Divide a real polynomial u by a real polynomial v.
    % INPUT
    % u is a vector of real coefficients of the polynomial
    %       Sum(i=0,m1; u(i+1)x^i)
    % b is a vector of real coefficients of the polynomial
    %       Sum(i=0,m2; v(i+1)x^i)
    % OUTPUT
    % q is a vector of real coefficients of the quotient polynomial
    %       Sum(i=0,m3; q(i+1)x^i)
    % r is a vector of real coefficients of the remainder polynomial
    %       Sum(i=0,m4; r(i+1)x^i)
    % 
    n = length(u)-1;
    nv = length(v);
    while (nv >= 1) && (v(nv) == 0.0)
        nv = nv - 1;
    end
    if nv < 1
        throw(MException('NumericalRecipes:poldiv','divide by zero polynomial'));
    end
    r = u;
    q = zeros(n+1,1);
    for k = n-nv+1:-1:0
        q(k+1) = r(nv+k)/v(nv);
        for j = nv+k-1:-1:k+1
            r(j) = r(j) - q(k+1)*v(j-k);
        end
    end
    for j = nv:n+1
        r(j) = 0.0;
    end
end