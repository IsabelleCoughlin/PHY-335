classdef SVD
    % Class for solving linear equations A*x=b using singular value
    % decomposition and related functions.
    %
    % Construct with the matrix A
    %         SVD_obj = NumericalRecipes.SVD(A);
    %
    % Methods:
    %
    % SVD_obj.solve(b,thresh) : 
    % Solves the set of n linear equations A*x=b using the pseudoinverse of
    % A.  b can be either a column vector or a matrix containing a set of
    % "k" column vectors.  It returns either a column vector or a matrix
    % containing a set of "k" column vectors representing the solution "x".
    % If present and non-negative, the optional argument "thresh" is the
    % threshold value below which singular values are considered zero.  If
    % thresh is absent or negative, a default value based on expected
    % roundoff error is used.
    %
    % SVD_obj.rank(thresh) :
    % Returns the rank of A after zeroing any singular values smaller than
    % thresh.  If thresh is absent or negative, a defulat value based on
    % expected roundoff error is used.
    %
    % SVD_obj.nullity(thresh) :
    % Returns the nullity of A after zeroing any singular values smaller
    % than thresh.  If thresh is absent or negative, a defulat value based
    % on expected roundoff error is used.
    %
    % SVD_obj.range(thresh) :
    % Returns in the columns of a matrix, an orthonormal basis for the
    % range of A. Singular values smaller than threshold are zeroed.  If
    % thresh is absent or negative, a defulat value based on expected
    % roundoff error is used. 
    %
    % SVD_obj.nullspace(thresh) :
    % Returns in the columns of a matrix, an orthonormal basis for the
    % nullspace of A. Singular values smaller than threshold are zeroed.
    % If thresh is absent or negative, a defulat value based on expected
    % roundoff error is used. 
    %
    % SVD_obj.inv_condition() :
    % Returns the reciprocal of the condition number of A
    %
    properties
        m
        n
        u
        v
        w
        tsh
    end
    methods
        function obj = SVD(A)
            [obj.m,obj.n] = size(A);
            if obj.n >= obj.m
                obj.u = zeros(size(A));
                obj.w = zeros(obj.n,obj.n);
                [obj.u(:,1:obj.m),obj.w(1:obj.m,:),obj.v] = svd(A,0);
            else
                [obj.u,obj.w,obj.v] = svd(A,0);
            end
            obj.tsh = 0.5*sqrt(double(obj.m+obj.n+1))*obj.w(1)*eps('double');
        end
        function x = solve(obj,b,thresh)
            if nargin == 2, thresh = -1; end
            if thresh >= 0.0
                tshl = thresh;
            else
                tshl = obj.tsh;
            end
            x = (obj.u')*b;
            for i=1:obj.n
                if obj.w(i,i) > tshl
                    x(i,:) = x(i,:)/obj.w(i,i);
                else
                    x(i,:) = 0.0;
                end
            end
            x = obj.v*x;
        end
        function nr = rank(obj,thresh)
            if nargin == 1, thresh = -1; end
            if thresh >= 0.0
                tshl = thresh;
            else
                tshl = obj.tsh;
            end
            nr = 0;
            for j=1:obj.n
                if obj.w(j,j) > tshl, nr = nr+1; end
            end
        end
        function nn  = nullity(obj,thresh)
            if nargin == 1, thresh = -1; end
            if thresh >= 0.0
                tshl = thresh;
            else
                tshl = obj.tsh;
            end
            nn = 0;
            for j=1:obj.n
                if obj.w(j,j) <= tshl, nn = nn+1; end
            end
        end
        function rnge = range(obj,thresh)
            if nargin == 1, thresh = -1; end
            if thresh >= 0.0
                tshl = thresh;
            else
                tshl = obj.tsh;
            end
            nr = 0;
            rnge = zeros(obj.m,obj.rank(thresh));
            for j=1:obj.n
                if obj.w(j,j) > tshl
                    nr = nr+1;
                    rnge(:,nr) = obj.u(:,j);
                end
            end
        end
        function nullspace = nullspace(obj,thresh)
            if nargin == 1, thresh = -1; end
            if thresh >= 0.0
                tshl = thresh;
            else
                tshl = obj.tsh;
            end
            nr = 0;
            nullspace = zeros(obj.n,obj.nullity(thresh));
            for j=1:obj.n
                if obj.w(j,j) <= tshl
                    nr = nr+1;
                    nullspace(:,nr) = obj.v(:,j);
                end
            end
        end
        function invcond = inv_condition(obj)
            if (obj.w(1,1) <=0.0) || (obj.w(obj.n,obj.n) <= 0.0)
                invcond = 0.0;
            else
                invcond = obj.w(obj.n,obj.n)/obj.w(1,1);
            end
        end
    end
end