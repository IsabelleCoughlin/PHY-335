function [ival,obj] = rawinterp(obj,jl,ix)
    % Given a value of x, this routing returns an interpolated value y and
    % stores an error estimate in dy.
    TINY = 1.e-10;
    ns = int16(1);
    c = zeros(obj.mm,1);
    d = zeros(obj.mm,1);
    hh = abs(ix - obj.xx(jl));
    for i=1:obj.mm
        h = abs(ix - obj.xx(i+jl-1));
        if h == 0
            obj.dy=0;
            ival = obj.yy(i+jl-1);
            return;
        else
            if h < hh
                ns=i;
                hh=h;
            end
        end
        c(i) = obj.yy(i+jl-1);
        d(i) = c(i)*(1+TINY);
    end
    ival = obj.yy(ns+jl-1);
    ns = ns-1;
    for m=1:obj.mm-1
        for i=1:obj.mm-m
            w = c(i+1)-d(i);
            h = obj.xx(i+jl-1+m)-ix;
            t = (obj.xx(i+jl-1)-ix)*d(i)/h;
            dd = t - c(i+1);
            if dd == 0.0
                throw(MException('NumericalRecipes:Rat_interp:rawinterp','pole at interpolation value'));
            end
            dd = w/dd;
            d(i) = c(i+1)*dd;
            c(i) = t*dd;
        end
        if (2*ns) < (obj.mm-m)
            obj.dy = c(ns+1);
        else
            obj.dy = d(ns);
            ns = ns-1;
        end
        ival = ival+obj.dy;
    end
end