classdef Rat_interp < NumericalRecipes.Base_interp
    % Diagonal rational function interpolation object.
    %
    % Construct with x and y vectors and the number M of points to be 
    % used locally, then call interp for interpolated values.  
    % 
    % interp_object = NumericalRecipes.Rat_interp(x,y,M)
    %
    % function y = interp_object.interp(x)
    %               x : must be a single double precision number. Vectors
    %                   are not allowed.
    %               y : a single double precision number containing the
    %                   interpolated function value at x.
    %
    properties
        dy = 0.0; % Stored error estimate for latest interpolation
    end
    methods
        function obj = Rat_interp(x,y,m)
            if nargin > 0
                super_args{1} = x;
                super_args{2} = y;
                super_args{3} = m;
            else
                super_args = {};
            end
           obj = obj@NumericalRecipes.Base_interp(super_args{:});
        end
    end
end
    