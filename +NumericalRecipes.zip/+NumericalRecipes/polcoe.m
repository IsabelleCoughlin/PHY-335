function coef = polcoe(x,y)
    % Get coefficients of fitting polynomial
    %
    % INPUT
    % x and y are vectors containing a tabulated functions y(i)=f(x(i)).
    % OUTPUT
    % coef returns a vector of coefficients such that
    %           y(i) = Sum(j=0..n-1,coef(j)*x(i)^j
    %
    n = length(x);
    s = zeros(n,1);
    coef = zeros(n,1);
    s(n) = -x(1);
    for i=2:n
        for j=n-i+1:n-1
            s(j) = s(j) - x(i)*s(j+1);
        end
        s(n) = s(n) - x(i);
    end
    for j=1:n
        phi = n;
        for k=n:-1:2
            phi =  (k-1)*s(k) + x(j)*phi;
        end
        ff = y(j)/phi;
        b=1;
        for k=n:-1:1
            coef(k) = coef(k) + b*ff;
            b = s(k) + x(j)*b;
        end
    end
end