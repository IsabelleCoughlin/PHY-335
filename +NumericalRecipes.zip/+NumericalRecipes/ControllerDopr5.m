classdef ControllerDopr5 < handle
    % Step size controller for fifth-order Dormand-Prince method.
    properties
        hnext=0;
        errold=1.0e-4;
        reject=false;
    end
    methods
        function [good,h] = success(obj,err,h)
            % Determines success or failure of a given step and determines
            % the appropriate stepsize to use.
            % If err <= 1, good returns as True and hnext is set to the
            % estimated optimal step size for the next step.
            % If err > 1, good returns as False so the give step should be
            % rejected and h is set to the estimated optimal step size for
            % recomputing the step.
            beta=0.0;
            alpha=0.2-beta*0.75;
            safe=0.9;
            minscale=0.2;
            maxscale=10.0;
            if err <= 1.0
                if err == 0.0
                    scale = maxscale;
                else
                    scale = safe*(err^(-alpha))*(obj.errold^beta);
                    if scale < minscale, scale=minscale; end
                    if scale > maxscale, scale=maxscale; end
                end
                if obj.reject
                    obj.hnext = h*min(scale,1.0);
                else
                    obj.hnext = h*scale;
                end
                obj.errold = max(err,1.0e-4);
                obj.reject = false;
                good = true;
                return;
            else
                scale = max(safe*(err^(-alpha)),minscale);
                h = h*scale;
                obj.reject = true;
                good = false;
                return
            end
        end
    end
end