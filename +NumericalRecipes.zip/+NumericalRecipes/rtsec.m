function rts =  rtsec(funcc,x1,x2,xacc)
    % Attempt to find the root of a given function using the secant method.
    %
    % Use the secant method to find a root of the function funcc known to
    % exist in the interval x1..x2.  The root will be found with accuracy
    % xacc. 
    % INPUT
    % funcc is the function to be tested.  It can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle.  x1 and x2
    % are the known bracket for a root.  The root will be found an
    % uncertainty of +/- xacc.
    % OUTPUT
    % The location of the root.
    % 
    MAXIT=30;
    if strcmp(class(funcc),'function_handle')
        func = funcc;
    elseif isa(funcc,'NumericalRecipes.Functor')
        func = @ funcc.func;
    else
        throw(MException('NumericalRecipes:rtsec','No Function or Functor'));
    end
    fl = func(x1);
    f = func(x2);
    if abs(fl) < abs(f)
        rts = x1;
        xl = x2;
        swap = fl;
        fl = f;
        f = swap;
    else
        xl = x1;
        rts = x2;
    end
    for j = 1:MAXIT
        dx = (xl - rts)*f/(f - fl);
        xl = rts;
        fl = f;
        rts = rts + dx;
        f = func(rts);
        if (abs(dx) < xacc) || (f ==0.0)
            return
        end
    end
    throw(MException('NumericalRecipes:rtsec','exceed maximum iterations'));
end