function rtn = rtnewt(funcd,x1,x2,xacc)
    % Attempt to find the root of a given function using Newton's method.
    %
    % Use Newton's method to find a root of the function funcd known to
    % exist in the interval x1..x2.  The root will be found with accuracy
    % xacc. 
    % INPUT
    % funcd is the function to be tested.  It must be represented by a
    % NumericalRecipes 'FunctorD' which can evaluate a function and its
    % first derivative.  x1 and x2  are the known bracket for a root.  The
    % root will be found an uncertainty of +/- xacc.
    % OUTPUT
    % The location of the root.
    % 
    JMAX = 20;
    rtn = 0.5*(x1 + x2);
    for j=1:JMAX
        f = funcd.func(rtn);
        df = funcd.df(rtn);
        dx = f/df;
        rtn = rtn - dx;
        if (x1 - rtn)*(rtn - x2) < 0.0
            throw(MException('NumericalRecipes:rtnewt','jumped out of brackets'));
        end
        if abs(dx) < xacc
            return
        end
    end
    throw(MException('NumericalRecipes:rtnewt','exceeded maximum iterations'));
end
