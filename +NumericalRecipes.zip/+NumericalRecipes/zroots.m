function roots = zroots(a,polish)
    % Find all the complex roots of a polynomial.
    %
    % Use Laguerre's method to find all roots of a polynomial.  
    % INPUT
    % a is a vector of complex coefficients of the polynomial
    %       Sum(i=0,m;a(i+1)x^i)
    % polish is a boolian that indicates if the roots should be polished to
    % roundoff error using Laguerre's method.
    % OUTPUT
    % roots is vector containing the complex roots.
    % 
    EPS = 1.e-14;
    m = length(a)-1;
    roots = zeros(m,1);
    ad = a;
      for j = m:-1:1
        x=0.0;
        ad_v = ad(1:j+1);
        x = NumericalRecipes.laguer(ad_v,x);
        if abs(imag(x)) < 2.0*EPS*abs(real(x))
            x=complex(real(x),0.0);
        end
        roots(j) = x;
        b = ad(j+1);
        for jj = j:-1:1
          c = ad(jj);
          ad(jj) = b;
          b = x*b + c;
        end
      end
      if  polish
        for j = 1:m
          roots(j) = NumericalRecipes.laguer(a,roots(j));
        end
      end
      for j = 2:m
        x = roots(j);
        for i = j-1:-1:1
          if real(roots(i)) < real(x)
              break
          end
          roots(i+1) = roots(i);
          if i == 1
              i = 0;
              break
          end
        end
        roots(i+1) = x;
      end
end
