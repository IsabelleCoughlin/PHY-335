function integral = qsimp(func,a,b,varargin)
    % Returns the integral of func on the interval between a and b
    % using Simpson's rule
    %
    % INPUT
    % func is the function to be integrated.  It can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle.  a and b are
    % the lower and upper limits of integration.  A single optional
    % argument is the fractional accuracy (defaults to 1.e-10).
    % OUTPUT
    % The integral of the given function.
    %     
    eps = 1.0e-10;
    if size(varargin,2) == 1
        eps = varargin{1};
    else
        if size(varargin,2) > 1
            throw(MException('NumericalRecipes:qsimp','Too many inputs'));
        end
    end
    jmax = int16(20);
    ost = 0.0;
    os = ost;
    t = NumericalRecipes.Trapzd(func,a,b);
    for j=1:jmax
        [st,t] = t.next();
        s = (4*st - ost)/3.0;
        if j >= 5
            if (abs(s - os) < eps*abs(os)) || (s == 0.0 && olds == 0.0)
                integral = s;
                return
            end
        end
        os = s;
        ost = st;
    end
    throw(MException('NumericalRecipes:qsimp','Too many iterations'));
end