function r = tridag(a,b,c,r)
    % Find the solution of a tridiagonal system of linear equations.
    % The only non-zero elements of the matrix are on the diagonal plus or
    % minus one column.  The matrix elements below the diagonal are stored
    % in a vector a, those on the diagonal in a vector b, and those above
    % the diagonal in a vector c.  Note: the first element on the lower
    % diagonal is stored in the second element of the vector a.
    % r is the right-hand-side vector in A*x=r and the function returns the
    % solution vector x.
    %
    if b(1) == 0.0
        throw(MException('NumericalRecipes:tridag','b(1) = 0'));
    end
    n = length(r);
    bet = b(1);
    r(1) = r(1)/bet;
    for j=2:n
        b(j-1) = c(j-1)/bet;
        bet = b(j) - a(j)*b(j-1);
        if bet == 0.0
            throw(MException('NumericalRecipes:tridag','bet = 0'));
        end
        r(j) = (r(j) - a(j)*r(j-1))/bet;
    end
    for j=n-1:-1:1
        r(j) = r(j) - b(j)*r(j+1);
    end
end