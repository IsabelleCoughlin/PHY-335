function [x,its] = laguer(a,x)
    % Improve the complex root of a polynomial.
    %
    % Use Laguerre's method to improve a root x of a polynomial until it
    % converges to roundoff error.
    % INPUT
    % a is a vector of complex coefficients of the polynomial
    %       Sum(i=0,m;a(i+1)x^i)
    % x is the initial guess for a root.
    % OUTPUT
    % x is converged location of the root, and its is the number of
    % iterations taken to find this root.
    % 
    EPS = eps('double');
    MR = 8;
    MT = 10;
    MAXIT = MT*MR;
    frac = [0.0 0.5 0.25 0.75 0.13 0.38 0.62 0.88 1.0];
    m = length(a)-1;
    for iter=1:MAXIT
        its = iter;
        b = a(m+1);
        err = abs(b);
        d=0.0;
        f=0.0;
        abx = abs(x);
        for j = m:-1:1
            f = x*f + d;
            d = x*d + b;
            b = x*b + a(j);
            err = abs(b) + abx*err;
        end
        err = EPS*err;
        if abs(b) < err
            return
        end
        g = d/b;
        g2=  g*g;
        h = g2 - 2.0*f/b;
        sq = sqrt(double(m-1)*(double(m)*h-g2));
        gp = g + sq;
        gm = g - sq;
        abp = abs(gp);
        abm = abs(gm);
        if abp <abm
            gp = gm;
        end
        if max(abp,abm) >0.0
            dx = m/gp;
        else
            dx = exp(complex(log(1.0 + abx),double(iter)));
        end
        x1 = x - dx;
        if x == x1
            return
        end
        if mod(iter,MT) ~= 0
            x = x1;
        else
            x = x - dx*frac(iter/MT);
        end
    end
    throw(MException('NumericalRecipes:laguer','too many iterations'));
end