function [x,w] = gaulag(n,alf)
    % Compute abscissas and weights for n-point Gauss-Laguerre quadrature.
    %
    % Compute the integral of x^alpha * exp(-x) * f(x) over the
    % interval from 0..infinity.
    % INPUT
    % n is the number of points.  alf is the alpha paremeter of the
    % Laguerre polynomials.
    % OUTPUT
    % x contains the vector of abscissas, and y contain the vector of
    % weights.
    % 
    EPS = 1.0e-14;
    MAXIT = int16(10);
    x = zeros(n,1);
    w = zeros(1,n);
    for i=1:n
        if i == 1
            z = (1.0 + alf)*(3.0 + 0.92*alf)/(1.0 + 2.4*n + 1.8*alf);
        elseif i == 2
            z = z + (15.0 + 6.25*alf)/(1.0 + 0.9*alf + 2.5*n);
        else
            ai =i - 2;
            z = z + ((1.0 + 2.55*ai)/(1.9*ai) + 1.26*ai*alf/(1.0 + 3.5*ai))*(z - x(i - 2))/(1.0 + 0.3*alf);
        end
        for its=1:MAXIT
            p1 = 1.0;
            p2 = 0.0;
            for j=1:n
                p3 = p2;
                p2 = p1;
                p1 = ((2*j - 1 + alf - z)*p2 - (j - 1 + alf)*p3)/j;
            end
            pp = (n*p1 - (n + alf)*p2)/z;
            z1 = z;
            z = z1 - p1/pp;
            if abs(z - z1) <= EPS
                break
            end
            if its == MAXIT
                throw(MException('NumericalRecipes:gaulag','too many iterations'));
            end
        end
        x(i) = z;
        w(i) = -exp(gammaln(alf + n) - gammaln(double(n)))/(pp*n*p2);
    end
end