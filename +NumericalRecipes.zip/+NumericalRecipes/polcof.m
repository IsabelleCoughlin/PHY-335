function coef = polcof(x,y)
    % Get coefficients of fitting polynomial
    %
    % INPUT
    % x and y are vectors containing a tabulated functions y(i)=f(x(i)).
    % OUTPUT
    % coef returns a vector of coefficients such that
    %           y(i) = Sum(j=0..n-1,coef(j)*x(i)^j
    %
    n = length(x);
    coef = zeros(n,1);
    for j=1:n
        interp = NumericalRecipes.Poly_interp(x,y,n-j+1);
        coef(j) = interp.rawinterp(1,0);
        xmin = 1.e99;
        k = 0;
        for i=1:n-j+1
            if abs(x(i)) < xmin
                xmin = abs(x(i));
                k = i;
            end
            if x(i) ~= 0
                y(i) = (y(i)-coef(j))/x(i);
            end
        end
        for i=k+1:n-j+1
            y(i-1) = y(i);
            x(i-1) = x(i);
        end
    end
end