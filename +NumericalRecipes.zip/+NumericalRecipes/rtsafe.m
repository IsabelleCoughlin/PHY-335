function rts = rtsafe(funcd,x1,x2,xacc)
    % Attempt to find the root of a given function using a combination of
    % Newton-Raphson and bisection. 
    %
    % Use Newton-Raphson and bisection to "safely" find a root of the
    % function funcd known to exist in the interval x1..x2.  The root will
    % be found with accuracy xacc. 
    % INPUT
    % funcd is the function to be tested.  It must be represented by a
    % NumericalRecipes 'FunctorD' which can evaluate a function and its
    % first derivative.  x1 and x2  are the known bracket for a root.  The
    % root will be found an uncertainty of +/- xacc.
    % OUTPUT
    % The location of the root.
    % 
    MAXIT = 100;
    fl = funcd.func(x1);
    fh = funcd.func(x2);
    if ((fl > 0.0) && (fh > 0.0)) || ((fl < 0.0) && (fh < 0.0))
        throw(MException('NumericalRecipes:rtnewt','root must be bracketed'));
    end
    if fl == 0.0
        rts = x1;
        return
    elseif fh == 0.0
        rts = x2;
        return
    elseif fl < 0.0
        xl = x1;
        xh = x2;
    else
        xh = x1;
        xl = x2;
    end
    rts = 0.5*(x1 + x2);
    dxold = abs(x2 - x1);
    dx = dxold;
    f = funcd.func(rts);
    df = funcd.df(rts);
    for j=1:MAXIT
        if ((((rts - xh)*df - f)*((rts - xl)*df - f) > 0.0) || (abs(2.0*f) > abs(dxold*df)))
            dxold = dx;
            dx = 0.5*(xh - xl);
            rts = xl + dx;
            if xl == rts
                return
            end
        else
            dxold = dx;
            dx = f/df;
            temp = rts;
            rts = rts - dx;
            if temp == rts
                return
            end
        end
        if abs(dx) < xacc
            return
        end
        f = funcd.func(rts);
        df = funcd.df(rts);
        if f < 0.0
            xl = rts;
        else
            xh = rts;
        end
    end
    throw(MException('NumericalRecipes:rtsafe','exceeded maximum iterations'));
end