classdef Midsqu < NumericalRecipes.Midpnt
    % Class implementing the extended midpoint rule.
    % This routine is an exact replacement for Midpnt except that it
    % allows for an inverse square-root singularity in the integrand 
    % at the upper limit bb.
    %
    % Construct with the function to be integrated and the limits of
    % integration.  The function can either be a MATLAB function handle
    % or a NumericalRecipes 'Functor'.  Successive calls to next return
    % increasingly refined results for the integral.
    %
    %  int_class = NumercialRecipes.Midpnt(@(x) f(x),a,b); % Anonymous f(x)
    %         or = NumercialRecipes.Midpnt(@func,a,b);
    %         or = NumercialRecipes.Midpnt(Functor,a,b);
    %     
    properties
        borig
    end
    methods
        function obj = Midsqu(funcc,aa,bb)
            obj = obj@NumericalRecipes.Midpnt(funcc,0,sqrt(bb-aa));
            obj.borig = bb;
        end
        function val = func(obj,x)
            val = 2*x*obj.funk(obj.borig - x*x);
        end
    end
end