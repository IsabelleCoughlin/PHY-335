function b =  zbrent(funcc,x1,x2,tol)
    % Attempt to find the root of a given function using Brent's method.
    %
    % Use Brent's method to find a root of the function funcc known to
    % exist in the interval x1..x2.  The root will be found with accuracy
    % tol. 
    % INPUT
    % funcc is the function to be tested.  It can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle.  x1 and x2
    % are the known bracket for a root.  The root will be found an
    % uncertainty of +/- tol.
    % OUTPUT
    % The location of the root.
    % 
    ITMAX = 100;
    EPS = eps('double');
    if strcmp(class(funcc),'function_handle')
        func = funcc;
    elseif isa(funcc,'NumericalRecipes.Functor')
        func = @ funcc.func;
    else
        throw(MException('NumericalRecipes:zbrent','No Function or Functor'));
    end
    a = x1;
    b = x2;
    c = x2;
    fa = func(a);
    fb = func(b);
    if ((fa > 0.0) && (fb > 0.0)) ||  ((fa < 0.0) && (fb< 0.0))
        throw(MException('NumericalRecipes:zbrent','root must be bracketed'));
    end
    fc = fb;
    for iter=1:ITMAX
        if ((fb > 0.0) && (fc > 0.0)) || ((fb < 0.0) && (fc < 0.0))
            c = a;
            fc = fa;
            d = b - a;
            e = d;
        end
        if abs(fc) < abs(fb)
            a = b;
            b = c;
            c = a;
            fa = fb;
            fb = fc;
            fc = fa;
        end
        tol1 = 2.0*EPS*abs(b) + 0.5*tol;
        xm = 0.5*(c - b);
        if (abs(xm) < tol1) || (fb == 0.0)
            return
        end
        if (abs(e) >= tol1) && (abs(fa) > abs(fb))
            s = fb/fa;
            if a == c
                p = 2.0*xm*s;
                q = 1.0 - s;
            else
                q = fa/fc;
                r = fb/fc;
                p = s*(2.0*xm*q*(q - r) - (b - a)*(r - 1.0));
                q = (q - 1.0)*(r - 1.0)*(s - 1.0);
            end
            if p > 0.0
                q = -q;
            end
            p = abs(p);
            min1 = 3.*xm*q - abs(tol1*q);
            min2 = abs(e*q);
            if min1 < min2
                min = min1;
            else
                min = min2;
            end
            if 2.0*p < min
                e = d;
                d = p/q;
            else
                d = xm;
                e = d;
            end
        else
            d = xm;
            e = d;
        end
        a = b;
        fa = fb;
        if abs(d) > tol1
            b = b + d;
        else
            if tol1 > 0
                b = b + xm;
            else
                b = b - xm;
            end
        end
        fb = func(b);
    end
    throw(MException('NumericalRecipes:zbrent','exceeding maximum iterations'));
end
