classdef Output < handle
    % Base class for the output of information during the integraton of the
    % set of ODEs. 
    %
    % Construct with an integer that defines how often the output is saved.
    % The output points will be nsave+1 uniformly spaced points including
    % x1 and x2.  If nsave <=0, output is saved at every integration step
    % (ie at the actual points where the stepper happens to land).
    %
    % Output_obj = NumericalRecipes.Output(nsave);
    %
    % While most needs should be met with these options, a new class
    % derived from this can be created to add additional functionality.
    %
    properties
        kmax=500; % Current capacity of storage arrays.
        nvar=0;
        nsave=0; % Number of intervals to save at for dense output.
        dense=false % true if dens output requested.
        count=0 % number of values actually saved.
        x1
        x2
        xout
        dxout
        xsave % vector of stored values of x: xsave(count)
        ysave % matrix of saved y values: ysave(nvar,count)
    end
    methods
        function obj = Output(nsave)
            if nargin == 0
                obj.kmax = -1;
            else
                obj.kmax = 500;
                obj.nsave = nsave;
                obj.xsave = zeros(obj.kmax,1);
                if nsave >0
                    obj.dense = true;
                end
            end
        end
        function init(obj,neqn,xlo,xhi)
            % Called by Odeint constructor.
            obj.nvar = neqn;
            if obj.kmax == -1, return, end
            obj.ysave = zeros(obj.kmax,neqn);
            if obj.dense
                obj.x1 = xlo;
                obj.x2 = xhi;
                obj.xout = xlo;
                obj.dxout = (xhi-xlo)/obj.nsave;
            end
        end
        function resize(obj)
            % Resize storage arrays by a factor of two keeping saved data.
            kold = obj.kmax;
            obj.kmax = obj.kmax*2;
            obj.xsave(kold+1:obj.kmax) = 0.0;
            obj.ysave(kold+1:obj.kmax,:) = 0.0;
        end
        function save_dense(obj,s,xout,h)
            % Invokes dense_out function of stepper routine to produce
            % output at xout.  Normally called by out rather than directly.
            if obj.count == obj.kmax, obj.resize(), end
            obj.count = obj.count+1;
            obj.xsave(obj.count) = xout;
            for i = 1:obj.nvar
                obj.ysave(obj.count,i) = s.dense_out(i,xout,h);
            end
        end
        function save(obj,x,y)
            % Saves values of current x and y.
            if obj.kmax <=0, return, end
            if obj.count == obj.kmax, obj.resize(), end
            obj.count = obj.count+1;
            obj.xsave(obj.count) = x;
            obj.ysave(obj.count,:) = y(1,:);
        end
        function out(obj,nstp,x,y,s,h)
            % Called by Odeint to produce dense output.
            if ~obj.dense 
                throw(MException('NumericalRecipes:Output','dense output not set'));
            end
            if nstp == -1
                obj.save(x,y);
                obj.xout = obj.xout + obj.dxout;
            else
                while (x - obj.xout)*(obj.x2 - obj.x1) > 0.0
                    obj.save_dense(s,obj.xout,h);
                    obj.xout = obj.xout + obj.dxout;
                end
            end
        end
    end
end