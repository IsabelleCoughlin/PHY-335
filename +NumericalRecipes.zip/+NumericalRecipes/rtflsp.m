function rtf =  rtflsp(funcc,x1,x2,xacc)
    % Attempt to find the root of a given function using false-position.
    %
    % Use the false-position method to find a root of the function funcc
    % known to exist in the interval x1..x2.  The root will be found with
    % accuracy xacc. 
    % INPUT
    % funcc is the function to be tested.  It can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle.  x1 and x2
    % are the known bracket for a root.  The root will be found an
    % uncertainty of +/- xacc.
    % OUTPUT
    % The location of the root.
    % 
    MAXIT=30;
    if strcmp(class(funcc),'function_handle')
        func = funcc;
    elseif isa(funcc,'NumericalRecipes.Functor')
        func = @ funcc.func;
    else
        throw(MException('NumericalRecipes:rtflsp','No Function or Functor'));
    end
    fl = func(x1);
    fh = func(x2);
    if fl*fh > 0.0
        throw(MException('NumericalRecipes:rtflsp','root must be bracketed'));
    end
    if fl < 0.0
        xl = x1;
        xh = x2;
    else
        xl = x2;
        xh = x1;
        swap = fl;
        fl = fh;
        fh = swap;
    end
    dx = xh - xl;
    for j = 1:MAXIT
        rtf = xl + dx*fl/(fl - fh);
        f = func(rtf);
        if f < 0.0
            del = xl - rtf;
            xl = rtf;
            fl = f;
        else
            del = xh - rtf;
            xh = rtf;
            fh = f;
        end
        dx = xh - xl;
        if (abs(del) < xacc) || (f ==0.0)
            return
        end
    end
    throw(MException('NumericalRecipes:rtflsp','exceed maximum iterations'));
end