function rtb = rtbis(funcc,x1,x2,xacc)
    % Attempt to find the root of a given function using bisection.
    %
    % Use bisection to find a root of the function funcc known to exist
    % in the interval x1..x2.  The root will be found with accuracy xacc.
    % INPUT
    % funcc is the function to be tested.  It can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle.  x1 and x2
    % are the known bracket for a root.  The root will be found an
    % uncertainty of +/- xacc.
    % OUTPUT
    % The location of the root.
    % 
    JMAX = 50;
    if strcmp(class(funcc),'function_handle')
        func = funcc;
    elseif isa(funcc,'NumericalRecipes.Functor')
        func = @ funcc.func;
    else
        throw(MException('NumericalRecipes:rtbis','No Function or Functor'));
    end
    f = func(x1);
    fmid = func(x2);
    if f*fmid >= 0.0
        throw(MException('NumericalRecipes:rtbis','Root must be bracked for bisection'));
    end
    if f < 0.0
        dx = x2 - x1;
        rtb = x1;
    else
        dx = x1 - x2;
        rtb = x2;
    end
    for j=1:JMAX
        dx = 0.5*dx;
        xmid = rtb + dx;
        fmid = func(xmid);
        if fmid <= 0.0
            rtb = xmid;
        end
        if (abs(dx) < xacc) || (fmid==0.0)
            return;
        end
    end
    throw(MException('NumericalRecipes:rtbis','Too many bisections'));
end