classdef LUdcmp
    % Class for solving linear equations A*x=b using LU decomposition and
    % related functions.
    %
    % Construct with the matrix A
    %         LUdcmp_obj = NumericalRecipes.LUdcmp(A);
    %
    % Methods:
    %
    % LUdcmp_obj.solve(b) : 
    % Solves the set of n linear equations A*x=b using the stored LU
    % decomposition of A.  b can be either a column vector or a matrix
    % containing a set of "k" column vectors.  It returns either a column
    % vector or a matrix containing a set of "k" column vectors
    % representing the solution "x".
    %
    % LUdcmp_obj.inverse() :
    % Returns the matrix inverse of A.
    %
    % LUdcmp_obj.det() :
    % Returns the determinant of A.
    %
    % LUdcmp_obj.improve(x,b) :
    % Given a solution vector(or matrix) x to the linear equation A*x=b
    % where b is the right-hand-side vector(or matrix), return an improved
    % solution vector(or matrix) x.
    %
    properties
        L
        U
        P
        optl
        optu
    end
    methods
        function obj = LUdcmp(A)
            %[obj.L,obj.U,obj.P] = lu(A,'vector');
            [obj.L,obj.U,obj.P] = lu(A);
            obj.optl.LT = true;
            obj.optu.UT = true;
        end
        function x = solve(obj,b)
            %x = linsolve(obj.L,b(obj.P,:),obj.optl);
            x = linsolve(obj.L,obj.P*b,obj.optl);
            x = linsolve(obj.U,x,obj.optu);
        end
        function inv = inverse(obj)
            inv = obj.solve(eye(length(obj.P)));
            inv = linsolve(obj.L,obj.P,obj.optl);
            inv = linsolve(obj.U,inv,obj.optu);
        end
        function d = det(obj)
            %i = eye(size(obj.P));
            %d = det(i(obj.P,:))*prod(diag(obj.U));
            d = det(obj.P)*prod(diag(obj.U));
        end
        function x = mprove(obj,x,b)
            %b = obj.L*obj.U*x - b(obj.P,:);
            b = obj.L*obj.U*x - obj.P*b;
            b = linsolve(obj.L,b,obj.optl);
            x = x - linsolve(obj.U,b,obj.optu);
        end
    end
end