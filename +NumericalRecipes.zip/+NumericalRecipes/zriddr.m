function zrd = zriddr(funcc,x1,x2,xacc)
    % Attempt to find the root of a given function using Ridders' method.
    %
    % Use Ridders' method to find a root of the function funcc known to
    % exist in the interval x1..x2.  The root will be found with accuracy
    % xacc. 
    % INPUT
    % funcc is the function to be tested.  It can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle.  x1 and x2
    % are the known bracket for a root.  The root will be found an
    % uncertainty of +/- xacc.
    % OUTPUT
    % The location of the root.
    % 
    MAXIT=60;
    if strcmp(class(funcc),'function_handle')
        func = funcc;
    elseif isa(funcc,'NumericalRecipes.Functor')
        func = @ funcc.func;
    else
        throw(MException('NumericalRecipes:zriddr','No Function or Functor'));
    end
    fl=func(x1);
    fh=func(x2);
    if ((fl > 0.0) && (fh < 0.0)) || ((fl < 0.0) && (fh > 0.0))
        xl=x1;
        xh=x2;
        zrd = -9.99e99;
        for j= 1:MAXIT
            xm = 0.5*(xl + xh);
            fm = func(xm);
            s = sqrt(fm*fm - fl*fh);
            if s == 0.0
                return
            end
            if fl >= fh
                xnew = xm + (xm - xl)*fm/s;
            else
                xnew = xm - (xm - xl)*fm/s;
            end
            if abs(xnew-zrd) < xacc
                return
            end
            zrd = xnew;
            fnew=func(zrd);
            if fnew == 0.0
                return
            end
            if fm*fnew < 0.0
                xl = xm;
                fl = fm;
                xh = zrd;
                fh = fnew;
            elseif fl*fnew < 0.0
                xh = zrd;
                fh = fnew;
            elseif fh*fnew < 0.0
                xl = zrd;
                fl = fnew;
            else
                throw(MException('NumericalRecipes:zriddr','never get here'));
            end
            if abs(xh - xl) < xacc
                return
            end
        end
        throw(MException('NumericalRecipes:zriddr','exceed maximum iterations'));
    else
        if fl == 0.0
            zrd=x1;
            return
        elseif fh == 0.0
            zrd = x2;
            return
        else
            throw(MException('NumericalRecipes:zriddr','root must be bracketed'));
        end
    end
end
