classdef StepperDopr5 < NumericalRecipes.StepperBase
    % Dormand-Prince fifth-order Runge-Kutta step with monitoring of local
    % truncation error to ensure accuracy and adjust stepsize.
    %
    properties
        k2
        k3
        k4
        k5
        k6
        rcont1
        rcont2
        rcont3
        rcont4
        rcont5
        dydxnew
        con = NumericalRecipes.ControllerDopr5();
    end
    methods
        function obj = StepperDopr5(y,dydx,x,atol,rtol,density)
            if nargin == 0
                super_args = {};
            else
                super_args{1} = y;
                super_args{2} = dydx;
                super_args{3} = x;
                super_args{4} = atol;
                super_args{5} = rtol;
                super_args{6} = density;
            end
            obj = obj@NumericalRecipes.StepperBase(super_args{:});
            if nargin ~= 0, obj.init(super_args{:}); end
        end
        function init(obj,y,dydx,x,atol,rtol,dense)
                obj.x = x;
                obj.y = y;
                obj.dydx = dydx;
                obj.atol = atol;
                obj.rtol = rtol;
                obj.dense = dense;
                obj.n = length(y(1,:));
                obj.neqn = obj.n;
                obj.yout = zeros(1,obj.n);
                obj.yerr = zeros(1,obj.n);
                obj.k2 = zeros(1,obj.n);
                obj.k3 = zeros(1,obj.n);
                obj.k4 = zeros(1,obj.n);
                obj.k5 = zeros(1,obj.n);
                obj.k6 = zeros(1,obj.n);
                obj.rcont1 = zeros(1,obj.n);
                obj.rcont2 = zeros(1,obj.n);
                obj.rcont3 = zeros(1,obj.n);
                obj.rcont4 = zeros(1,obj.n);
                obj.rcont5 = zeros(1,obj.n);
                obj.dydxnew = zeros(1,obj.n);
                obj.EPS = eps('double');
        end
        [x, y, dydx] = step(obj,htry,derivs)
        dy(obj,h,derivs)
        prepare_dense(obj,h)
        y = dense_out(obj,i,x,h)
        err = error(obj)
    end
end