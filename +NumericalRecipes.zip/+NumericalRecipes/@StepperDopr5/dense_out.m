function y = dense_out(obj,i,x,h)
    s = (x - obj.xold)/h;
    s1 = 1.0 - s;
    y = obj.rcont1(i) + s*(obj.rcont2(i) + s1*(obj.rcont3(i) + s*(obj.rcont4(i) + s1*obj.rcont5(i))));
end