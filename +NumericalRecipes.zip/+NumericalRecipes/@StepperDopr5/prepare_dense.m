function prepare_dense(obj,h)
    d1=-12715105075.0/11282082432.0;
    d3=87487479700.0/32700410799.0;
    d4=-10690763975.0/1880347072.0;
    d5=701980252875.0/199316789632.0;
    d6=-1453857185.0/822651844.0;
    d7=69997945.0/29380423.0;
    obj.rcont1 = obj.y;
    ydiff = obj.yout - obj.y;
    obj.rcont2 = ydiff;
    bspl = h*obj.dydx - ydiff;
    obj.rcont3 = bspl;
    obj.rcont4 = ydiff - h*obj.dydxnew - bspl;
    obj.rcont5 = h*(d1*obj.dydx + d3*obj.k3 + d4*obj.k4 + d5*obj.k5 + d6*obj.k6 + d7*obj.dydxnew);
end