function [x, y, dydx] = step(obj,htry,derivs)
    h = htry;
    while true
        obj.dy(h,derivs);
        err = obj.error();
        [good,h] = obj.con.success(err,h);
        if good, break, end
        if abs(h) <= abs(obj.x)*obj.EPS
            throw(MException('NumericalRecipes:StepperDopr5.step','Stepsize underflow'));
        end
    end
    if obj.dense, obj.prepare_dense(h), end
    dydx = obj.dydxnew;
    obj.dydx = dydx;
    y = obj.yout;
    obj.y = y;
    obj.xold = obj.x;
    obj.hdid = h;
    x = obj.x + h;
    obj.x = x;
    obj.hnext = obj.con.hnext;
end