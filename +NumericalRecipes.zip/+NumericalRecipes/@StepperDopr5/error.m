function err = error(obj)
    err = 0.0;
    for i = 1:obj.n
        sk = obj.atol + obj.rtol*max(abs(obj.y(i)),abs(obj.yout(i)));
        err = err + (obj.yerr(i)/sk).^2;
    end
    err = sqrt(err/obj.n);
end