function [found,x1,x2]= zbrac(funcc,x1,x2)
    % Attempt to bracket a root of a given function.
    %
    % Given a function funcc and an initial guesed range x1..x2, the
    % routing expands the range geometrically until a root is bracketed or
    % until the range becomes too large.
    % INPUT
    % funcc is the function to be tested.  It can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle.  x1 and x2
    % are the inital guessed gange for the bracket.
    % OUTPUT
    % found is a boolean variable indicating whether or not a root was
    % bracketed.  If found is True, then x1 and x2 return the bracket.
    % 
    NTRY=50;
    FACTOR = 1.6;
    if x1 == x2
        throw(MException('NumericalRecipes:zbrac',' Bad inital range'));
    end
    if strcmp(class(funcc),'function_handle')
        func = funcc;
    elseif isa(funcc,'NumericalRecipes.Functor')
        func = @ funcc.func;
    else
        throw(MException('NumericalRecipes:zbrac','No Function or Functor'));
    end
    f1 = func(x1);
    f2 = func(x2);
    for j=0:NTRY
        if f1*f2 < 0.0
            found = true;
            return
        end
        if abs(f1) < abs(f2)
            x1 = x1 + FACTOR*(x1 - x2);
            f1 = func(x1);
        else
            x2 = x2 + FACTOR*(x2 - x1);
            f2 = func(x2);
        end
    end
    found = false;
end
        