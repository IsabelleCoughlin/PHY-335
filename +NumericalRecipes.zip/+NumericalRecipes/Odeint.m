classdef Odeint < handle
    % Driver class ODE solvers with adaptive stepsize controll.
    %
    % Construct with a Stepper object derived from a StepperBase (handle)
    % class, a vector of starting y values ystart, the integration range
    % x1..x2, the value of the absolute tolerance atol and the relative
    % tolerance rtol, the initial stepsize h, the minimum stepsize hmin, a
    % an output object derived from the Output (handle) class, and a user
    % supplied class derived from the FunctorODE (handle) class for
    % calculating the right-hand-side derivatives.
    %
    % out = NumericalRecipes.Output(...); % some class derived from Output
    % derivs = NumericalRecipes.FunctorODE(...); % some class derived from
    %                                              FunctorODE
    % ODE_object = NumericalRecipes.Odeint(NumericalRecipes.Stepper(),
    %                                      ystart,x1,x2,atol,rtol,h,hmin,
    %                                      out,derivs);
    % The integration can be performed by running
    % yret = ODE_object.integrate(); % yret is a vector of final values.
    %
    properties
        MAXSTP = int32(50000);
        EPS
        nok = int32(0);
        nbad = int32(0);
        nvar = int16(0);
        x1
        x2
        hmin
        dense = false;
        y
        dydx
        ystart
        out
        %
        %dsave
        %
        derivs
        s
        nstp = int32(0);
        x
        h
    end
    methods
        function obj = Odeint(Stepper,ystart,x1,x2,atol,rtol,h,hmin,out,derivs)
            obj.nvar = length(ystart(1,:));
            obj.y(1,:) = ystart;
            obj.dydx = zeros(1,obj.nvar);
            obj.ystart = ystart;
            obj.x = x1;
            obj.x1 = x1;
            obj.x2 = x2;
            obj.hmin = hmin;
            obj.dense = out.dense;
            obj.out = out;
            %
            %obj.dsave = derivs;
            %
            obj.derivs = @derivs.dydx;
            obj.s = Stepper;
            obj.s.init(obj.y,obj.dydx,obj.x,atol,rtol,obj.dense);
            obj.EPS = eps('double');
            obj.h = sign(x2-x1)*abs(h);
            obj.out.init(obj.s.neqn,x1,x2);
        end
        function yret = integrate(obj)
            obj.dydx = obj.derivs(obj.x,obj.y);
            if obj.dense
                obj.out.out(-1,obj.x,obj.y,obj.s,obj.h);
            else
                obj.out.save(obj.x,obj.y);
            end
            for i = 0:obj.MAXSTP
                obj.nstp = i;
                if (obj.x + obj.h*1.0001 -obj.x2)*(obj.x2 -obj.x1) > 0.0
                    obj.h = obj.x2 - obj.x;
                end
                [obj.x,obj.y,obj.dydx] = obj.s.step(obj.h,obj.derivs);
                if obj.s.hdid == obj.h
                    obj.nok = obj.nok+1;
                else
                    obj.nbad = obj.nbad+1;
                end
                if obj.dense
                    obj.out.out(i,obj.x,obj.y,obj.s,obj.s.hdid);
                else
                    obj.out.save(obj.x,obj.y);
                end
                if (obj.x-obj.x2)*(obj.x2-obj.x1) >= 0.0
                    obj.ystart = obj.y;
                    if (obj.out.kmax > 0) && (abs(obj.out.xsave(obj.out.count)-obj.x2) > 100.0*abs(obj.x2)*obj.EPS)
                        obj.out.save(obj.x,obj.y);
                    end
                    yret = obj.y;
                    %
                    %fprintf('%d Function evaluations\n',obj.dsave.counter);
                    %
                    return;
                end
                if abs(obj.s.hnext) <= obj.hmin
                    throw(MException('NumericalRecipes:Odeint','Step size too small'));
                end
                obj.h = obj.s.hnext;
            end
            throw(MException('NumericalRecipes:Odeint','Too many steps'));
        end
    end
end
