function [x,w] = gauher(n)
    % Compute abscissas and weights for n-point Gauss-Hermite quadrature.
    %
    % Compute the integral of exp(-x^2) * f(x) over the interval
    % -infinity..infinity.
    % INPUT
    % n is the number of points.
    % OUTPUT
    % x contains the vector of abscissas, and y contain the vector of
    % weights.
    %
    EPS = 1.0e-14;
    PIM4 = 1/(pi^0.25);
    MAXIT = int16(10);
    x = zeros(n,1);
    w = zeros(1,n);
    m=(n+1)/2;
    for i=1:m
        if i == 1
            z = sqrt(double(2*n + 1)) - 1.85575*(2*n + 1)^(-.016667);
        elseif i == 2
            z = z - 1.14*n^0.426/z;
        elseif i == 3
            z = 1.86*z - 0.86*x(1);
        elseif i == 4
            z = 1.91*z - 0.91*x(2);
        else
            z = 2.0*z - x(i - 2);
        end
        for its=1:MAXIT
            p1 = PIM4;
            p2 = 0.0;
            for j=1:n
                p3 = p2;
                p2 = p1;
                p1 = z*sqrt(2.0/j)*p2 - sqrt(double(j - 1)/dble(j))*p3;
            end
            pp = sqrt(2.0*n)*p2;
            z1 = z;
            z = z1 - p1/pp;
            if abs(z - z1) <= EPS
                break
            end
            if its == MAXIT
                throw(MException('NumericalRecipes:gauher','too many iterations'));
            end
        end
        x(i) = z;
        x(n + 1 - i) = -z;
        w(i) = 2.0/(pp*pp);
        w(n + 1 - i) = w(i);
    end
end