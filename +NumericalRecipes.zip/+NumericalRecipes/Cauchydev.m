classdef Cauchydev < NumericalRecipes.Ran
    % Class implementing Cauchy deviates
    %
    % Construct with gaussian parameters mu, sig, and a seed
    %   rand_obj = NumericalRecipes.Cauchydev(mu,sig,seed)
    % Usage:
    %   rand_obj.dev() returns a random double precission number that is a
    %   random deviate from the Cauchy distribution 
    %               1/(pi*sig)*(1+ (x-mu)^2/sig^2)^(-1)
    %
    properties
        mu
        sig
    end
    methods
        function obj = Cauchydev(mu,sig,i)
            obj = obj@NumericalRecipes.Ran(i);
            obj.mu = mu;
            obj.sig = sig;
        end
        function val = dev(obj)
            while(true)
                v1 = 2.0*obj.doub() - 1.0;
                v2 = obj.doub();
                if (v1*v1 + v2*v2 < 1.0) && (v2 ~= 0.0)
                    break
                end
            end
            val = obj.mu + obj.sig*v1/v2;
        end
    end
end