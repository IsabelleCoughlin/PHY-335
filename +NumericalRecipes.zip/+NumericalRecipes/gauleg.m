function [x,w] = gauleg(n,x1,x2)
    % Compute abscissas and weights for n-point Gauss-Legendra quadrature.
    %
    % Compute the integral of  f(x) over the interval from x1..x2.
    % INPUT
    % x1 and x2 are the limits of integration, n is the number of points.
    % OUTPUT
    % x contains the vector of abscissas, and y contain the vector of
    % weights.
    %
    EPS = 1.0e-14;
    m = (n + 1)/2;
    xm = 0.5*(x2 + x1);
    xl = 0.5*(x2 - x1);
    x = zeros(n,1);
    w = zeros(1,n);
    for i=1:m
        z=cos(pi*(i - 0.25)/(n + 0.5));
        while true
            p1 = 1.0;
            p2 = 0.0;
            for j=1:n
                p3 = p2;
                p2 = p1;
                p1 = ((2.0*j -1.0)*z*p2 - (j - 1.0)*p3)/j;
            end
            pp = n*(z*p1 - p2)/(z*z - 1.d0);
            z1 = z;
            z = z1 - p1/pp;
            if abs(z - z1) <= EPS
                break
            end
        end
        x(i) = xm - xl*z;
        x(n + 1 - i) = xm + xl*z;
        w(i) = 2.0*xl/((1.0 - z*z)*pp*pp);
        w(n + 1 - i) = w(i);
    end
end