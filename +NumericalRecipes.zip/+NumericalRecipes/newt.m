function [x,check] = newt(x,vecfunc)
    % Use Newton's method to find the root of a vector of functions in
    % n-dim space. 
    %
    % Given an initial guess for a root in n dimensions, find the root by a
    % globally convergent Newton's method.
    % INPUT
    % x is a vector containing the n-dimension initial guess for a root.
    % vecfunc is a vector of function of the n-dim position vector. It can
    % be either a NumericalRecipes 'Functor', or a MATLAB function handle.
    % OUTPUT
    % x is a vector containing the n-dimensional root.  check is a boolean
    % which is False on a normal return and True if the function has
    % converged to a local minimum.
    %
    MAXITS = int16(200);
    TOLF = 1.e-8; TOLMIN = 1.e-12; STPMX = 100.0;
    TOLX = eps('double');
    n = length(x);
    nrfmin = NumericalRecipes.NRfmin(vecfunc);
    fmin = @nrfmin.func;
    nrfdjac = NumericalRecipes.NRfdjac(vecfunc);
    fdjac = @nrfdjac.func;
    f = fmin(x);
    test = max(0.0,max(abs(nrfmin.fvec)));
    if test < 0.01*TOLF; check = false; return, end
    bsum = sum(x.^2);
    stpmax = STPMX*max(sqrt(bsum),double(n));
    for its=1:MAXITS
        fjac = fdjac(x,nrfmin.fvec);
        g = (fjac')*nrfmin.fvec;
        xold = x;
        fold = f;
        p = -nrfmin.fvec;
        alu = NumericalRecipes.LUdcmp(fjac);
        p = alu.solve(p);
        [x,f,check] = NumericalRecipes.lnsrch(xold,fold,g,p,stpmax,fmin);
        test = max(0.0,max(abs(nrfmin.fvec)));
        if test < TOLF
            check = false;
            return
        end
        if check
            test = 0.0;
            den = max(f,0.5*double(n));
            for i=1:n
                temp = abs(g(i))*max(abs(x(i)),1.0)/den;
                if temp > test, test = temp; end
            end
            check = (test < TOLMIN);
            return;
        end
        test = 0.0;
        for i=1:n
            temp = (abs(x(i) - xold(i)))/max(abs(x(i)),1.0);
            if temp > test, test = temp; end
        end
        if test < TOLX, return, end
    end
    throw(MException('NumericalRecipes:newt','MAXITS exceeded'));
end