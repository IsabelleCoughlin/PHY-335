function [x,w] = gaujac(n,alf,bet)
    % Compute abscissas and weights for n-point Gauss-Jacobi quadrature.
    %
    % Compute the integral of (1-x)^alpha * (1-x)^beta * f(x) over the
    % interval from -1..1.
    % INPUT
    % n is the number of points.  alf and bet are the alpha and beta 
    % paremeter of the Gauss-Jacobi quadrature formula.
    % OUTPUT
    % x contains the vector of abscissas, and y contain the vector of
    % weights.
    % 
    EPS = 1.0e-14;
    MAXIT = int16(10);
    x = zeros(n,1);
    w = zeros(1,n);
    for i=1:n
        if i == 1
            an = alf/n;
            bn = bet/n;
            r1 = (1.0 + alf)*(2.78/(4.0 + n*n) + 0.768*an/n);
            r2 = 1.0 + 1.48*an + 0.96*bn +0.452*an*an + 0.83*an*bn;
            z = 1.0 - r1/r2;
        elseif i == 2
            r1 = (4.1 + alf)/((1.0 + alf)*(1.0 + 0.156*alf));
            r2 = 1.0 + 0.06*(n-8.0)*(1.0 + 0.12*alf)/n;
            r3 = 1.0 + 0.012*bet*(1.0 + 0.25*abs(alf))/n;
            z = z - (1.0 - z)*r1*r2*r3;
        elseif i == 3
            r1 = (1.67 + 0.28*alf)/(1.0 + 0.37*alf);
            r2 = 1.0 + 0.22*(n - 8.0)/n;
            r3 = 1.0 + 8.0*bet/((6.28 + bet)*n*n);
            z = z - (x(1) - z )*r1*r2*r3;
        elseif i == n-1
            r1 = (1.0 + 0.235*bet)/(0.766 + 0.119*bet);
            r2 = 1.0/(1.0 + 0.639*(n - 4.0)/(1.0 + 0.71*(n-4.0)));
            r3 = 1.0/(1.0 + 20.0*alf/((7.5 + alf)*n*n));
            z = z + (z - x(n - 3))*r1*r2*r3;
        elseif i == n
            r1 = (1.0 + 0.37*bet)/(1.67 + 0.28*bet);
            r2 = 1.0/(1.0 + 0.22*(n-8.0)/n);
            r3 = 1.0/(1.0 + 8.0*alf/((6.28 + alf)*n*n));
            z = z + (z - x(n - 2))*r1*r2*r3;
        else
            z = 3.0*x(i - 1) - 3.0*x(i - 2) + x(i - 3);
        end
        alfbet = alf + bet;
        for its=1:MAXIT
            temp = 2.0 + alfbet;
            p1 = (alf - bet + temp*z)/2.0;
            p2=1.0;
            for j=2:n
                p3 = p2;
                p2 = p1;
                temp = 2*j + alfbet;
                a = 2*j*(j + alfbet)*(temp - 2.0);
                b = (temp - 1.0)*(alf*alf - bet*bet + temp*(temp - 2.0)*z);
                c = 2.0*(j - 1 + alf)*(j - 1 + bet)*temp;
                p1 = (b*p2 - c*p3)/a;
            end
            pp = (n*(alf - bet - temp*z)*p1 + 2.0*(n + alf)*(n + bet)*p2)/(temp*(1.0 - z*z));
            z1 = z;
            z = z1 - p1/pp;
            if abs(z - z1) <= EPS
                break
            end
            if its == MAXIT
                throw(MException('NumericalRecipes:gaujac','too many iterations'));
            end
        end
        x(i) = z;
        w(i) = exp(gammln(alf + n) + gammln(bet + n) - gammln(n + 1.0) - gammln(n + alfbet+1.0))*temp*2.0^alfbet/(pp*p2);
    end
end