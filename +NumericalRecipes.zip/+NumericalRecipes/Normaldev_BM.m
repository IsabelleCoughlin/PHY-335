classdef Normaldev_BM < NumericalRecipes.Ran
    % Class implementing normal deviates using the Box-Muller method
    %
    % Construct with gaussian parameters mu, sig, and a seed
    %   rand_obj = NumericalRecipes.Normaldev_BM(mu,sig,seed)
    % Usage:
    %   rand_obj.dev() returns a random double precission number that is a
    %   random deviate from the Gaussian distribution 
    %               1/(sig*sqrt(2*pi))*exp(-(x-mu)^2/(2*sig^2))
    %
    properties
        mu
        sig
        storedval=0.0;
    end
    methods
        function obj = Normaldev_BM(mu,sig,i)
            obj = obj@NumericalRecipes.Ran(i);
            obj.mu = mu;
            obj.sig = sig;
        end
        function val = dev(obj)
            if obj.storedval == 0.0
                while(true)
                    v1 = 2.0*obj.doub() - 1.0;
                    v2 = 2.0*obj.doub() - 1.0;
                    rsq = v1*v1 + v2*v2;
                    if (rsq < 1.0) && (rsq > 0)
                        break
                    end
                end
                fac = sqrt(-2.0*log(rsq)/rsq);
                obj.storedval = v1*fac;
                val = obj.mu + obj.sig*v2*fac;
            else
                fac = obj.storedval;
                obj.storedval = 0.0;
                val = obj.mu + obj.sig*fac;
            end
        end
    end
end