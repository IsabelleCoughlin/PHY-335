classdef NRfdjac < handle
    % Utility class that computes the forward-difference approximation to
    % the Jacobian of a vector function.
    %
    % Construct with a vector function func that can be either a
    % NumericalRecipes 'Functor', or a MATLAB function handle. 
    %
    properties
        EPS = 1.e-8;
        funcc
    end
    methods
        function obj = NRfdjac(func)
            if strcmp(class(func),'function_handle')
                obj.funcc = func;
            else
                if isa(func,'NumericalRecipes.Functor')
                    obj.funcc = @ func.func;
                else
                    throw(MException('NumericalRecipes:NRfdjac','No Function or Functor'));
                end
            end
        end
        function df = func(obj,x,fvec)
            n = length(x);
            df = zeros(n,n);
            xh = x;
            for j=1:n
                temp = xh(j);
                h = obj.EPS*abs(temp);
                if h == 0, h = obj.EPS; end
                xh(j) = temp+h; % trick to reduce finite-precision error
                h = xh(j) - temp;
                f = obj.funcc(xh);
                xh(j) = temp;
                for i=1:n
                    df(i,j) = (f(i) - fvec(i))/h;
                end
            end
        end
    end
end