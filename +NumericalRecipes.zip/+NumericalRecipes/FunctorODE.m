classdef FunctorODE < handle
    % Abstract base class that is used to pass coupled sets of
    % Ordinary Differential Equations as arguments to other functions. 
    %
    methods (Abstract)
        % 'Abstract' methods are used to define how a
        % particular method will work, but do not actually
        % have any code that implements them.
        %
        % In this case, the FunctorODE class defines a single
        % method "dydx" that takes two arguements, 'x' and
        % a vector 'y' of function values at 'x', then returns a vector
        % 'derivs' that contains the "right-hand-sides" that
        % define the coupled set of ODEs.
        derivs = dydx(obj,x,y)
    end
end