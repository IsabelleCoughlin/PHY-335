function [x,f,check] = lnsrch(xold,fold,g,p,stpmax,funcc)
    % Perform a line search along a specified direction.
    %
    % Given an n-dimensional point xold, the value and gradient of a
    % vector function at that point, and a direction, find a new point
    % along that direction where the function has decreased "sufficiently".
    % INPUT
    % xold is a vector containing the n-dimensional point.  fold is a
    % vector containing the values of the function funcc at xold and g is
    % the vector containing the gradients of the vector function funcc at
    % xold. p is a vector representing the direction in which to search for
    % a new position.  stpmax limits the length of steps.  funcc is the
    % vector function being tested.  It can be either a NumericalRecipes
    % 'Functor', or a MATLAB function handle.
    % OUTPUT
    % x ia a vector contining the new n-dimensional point, and f is the
    % vector of values of funcc evaluated at this point.
    % check is a boolean value that is False when the routine exits
    % normally
    % 
    ALF = 1.0e-4;
    TOLX = eps('double');
    alam2 = 0.0;
    f2 = 0.0;
    if strcmp(class(funcc),'function_handle')
        func = funcc;
    else
        if isa(funcc,'NumericalRecipes.FunctorV')
            func = @ funcc.func;
        else
            throw(MException('NumericalRecipes:lnsrch','No Function or Functor'));
        end
    end
    n=length(xold);
    check = false;
    psum = sqrt(sum(p.*p));
    if psum > stpmax, p = p*(stpmax/psum); end
    slope = sum(g.*p);
    if slope >= 0.0
        throw(MException('NumericalRecipes:lnsrch','Roundoff problem'));
    end
    test = 0.0;
    for i=1:n
        temp = abs(p(i))/max(abs(xold(i)),1.0);
        if temp > test, test = temp; end;
    end
    alamin = TOLX/test;
    alam = 1.0;
    while true
        x = xold + alam*p';  % assumes x is a row- and p a column-vector.
        f = func(x);
        if alam < alamin
            x = xold;
            check = true;
            return
        elseif f <= fold + ALF*alam*slope, return
        else
            if alam == 1.0
                tmplam = -slope/(2.0*(f - fold-slope));
            else
                rhs1 = f - fold - alam*slope;
                rhs2 = f2 - fold - alam2*slope;
                a = (rhs1/(alam*alam) - rhs2/(alam2*alam2))/(alam - alam2);
                b = (-alam2*rhs1/(alam*alam) + alam*rhs2/(alam2*alam2))/(alam-alam2);
                if a == 0.0
                    tmplam = -slope/(2.0*b);
                else
                    disc = b*b - 3.0*a*slope;
                    if disc < 0.0
                        tmplam = 0.5*alam;
                    elseif b <= 0.0
                        tmplam = (-b+sqrt(disc))/(3.0*a);
                    else
                        tmplam = -slope/(b+sqrt(disc));
                    end
                end
                if tmplam > 0.5*alam, tmplam = 0.5*alam; end
            end
        end
        alam2 = alam;
        f2 = f;
        alam = max(tmplam,0.1*alam);
    end
end