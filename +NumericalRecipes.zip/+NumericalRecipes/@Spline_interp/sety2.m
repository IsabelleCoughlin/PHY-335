function y2 = sety2(obj,yp1,ypn)
    % This routine stores an array y2 with second derivatives of the
    % interpolating function at the tabulated points.  If yp1 or ypn are >=
    % to 1.e99, the routines is signaled to set the corresponding boundary
    % condition for a natural spline with zero second derivative on the
    % boundary; otherwise, they are the values of the first derivatives at
    % the endpoints.
    y2 = zeros(length(obj.xx),1);
    n = length(y2);
    u = zeros(n-1,1);
    if yp1 > 0.99e99 
        y2(1) = 0; u(1) = 0;
    else
        y2(1) = -0.5;
        u(1) = (3.0/(obj.xx(2) - obj.xx(1)))*((obj.yy(2) - obj.yy(1))/(obj.xx(2) - obj.xx(1)) - yp1);
    end
    for i=2:n-1
        sig = (obj.xx(i) - obj.xx(i-1))/(obj.xx(i+1) - obj.xx(i-1));
        p = sig*y2(i-1)+2;
        y2(i) = (sig - 1)/p;
        u(i) = (obj.yy(i+1) - obj.yy(i))/(obj.xx(i+1) - obj.xx(i)) - (obj.yy(i) - obj.yy(i-1))/(obj.xx(i) - obj.xx(i-1));
        u(i) = (6*u(i)/(obj.xx(i+1) - obj.xx(i-1)) - sig*u(i-1))/p;
    end
    if ypn > 0.99e99
        qn = 0; un = 0;
    else
        qn = 0.5;
        un = (3/(obj.xx(n)-obj.xx(n-1)))*(ypn - (obj.yy(n) - obj.yy(n-1))/(obj.xx(n) - obj.xx(n-1)));
    end
    y2(n) = (un - qn*u(n-1))/(qn*y2(n-1) + 1);
    for k=n-1:-1:1
        y2(k) = y2(k)*y2(k+1) + u(k);
    end
end