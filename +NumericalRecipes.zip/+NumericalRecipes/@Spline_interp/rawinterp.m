function [ival,obj] = rawinterp(obj,jl,ix)
    % Given a value of x, this routing returns the cubic spline
    % interpolated value y.
    klo=jl; khi=jl+1;
    h = obj.xx(khi) - obj.xx(klo);
    if h == 0.0
        throw(MException('NumericalRecipes:Spline_interp:rawinterp','Bad input to routine splint'));
    end
    a = (obj.xx(khi) - ix)/h;
    b = (ix - obj.xx(klo))/h;
    ival = a*obj.yy(klo) + b*obj.yy(khi) + ((a^3 - a)*obj.y2(klo) + (b^3 - b)*obj.y2(khi))*(h^2)/6;
end