classdef Spline_interp < NumericalRecipes.Base_interp
    % Cubic spline interpolation object.  
    %
    % Construct with x and y vectors, and (optionally) values of the 
    % first derivative at the endpoints, then call interp for interpolated 
    % values.
    % 
    % interp_obj = NumericalRecipes.Spline_interp(x,y)
    %         or = NumericalRecipes.Spline_interp(x,y,yp1,yp2)
    %
    % function y = interp_object.interp(x)
    %               x : must be a single double precision number. Vectors
    %                   are not allowed.
    %               y : a single double precision number containing the
    %                   interpolated function value at x.
    %
    properties
        y2;
    end
    methods
        function obj = Spline_interp(x,y,varargin)
            if nargin > 0
                super_args{1} = x;
                super_args{2} = y;
                super_args{3} = 2;
            else
                super_args = {};
            end
           obj = obj@NumericalRecipes.Base_interp(super_args{:});
           if nargin == 2
               obj.y2 = obj.sety2(1.0e99,1.0e99);
           elseif length(varargin )== 2
               obj.y2 = obj.sety2(varargin{1},varargin{2});
           else
               throw(MException('NumericalRecipes:Spline_interp', ...
                   'constructor takes either 2 ao 4 arguments'));
           end
        end
        y2 = sety2(obj,yp1,ypn)
    end
end
    