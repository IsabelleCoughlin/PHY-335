function integral = qromo(q,varargin)
    % Returns the open integral of function and range defined in q
    % using Romberg integration.
    %
    % INPUT
    % q is an object such as Midpnt or a class derived from it.  It
    % contains the information about the function and integration limits.
    % A single optional argument is the fractional accuracy (defaults 
    % to 1.e-10).
    % OUTPUT
    % The integral of the given function.
    %     
    eps = 3.0e-9;
    if size(varargin,2) == 1
        eps = varargin{1};
    else
        if size(varargin,2) > 1
            throw(MException('NumericalRecipes:qromo','Too many inputs'));
        end
    end
    jmax = int16(14);
    jmaxp = jmax+1;
    K = int16(5);
    s = zeros(jmax,1);
    h = ones(jmaxp,1);
    for j=1:jmax
        [s(j),q] = q.next();
        if j >= K
            polint = NumericalRecipes.Poly_interp(h,s,K);
            [ss,polint] = polint.rawinterp(j-K+1,0.0);
            if abs(polint.dy) <= eps*abs(ss)
                integral = ss;
                return
            end
        end
        h(j+1) = h(j)/9.0;
    end
    throw(MException('NumericalRecipes:qromo','Too many iterations'));
end