classdef Quadrature
    % Abstract base class for elementary quadrature algorithms
    properties
        n=0;
    end
    methods
        function obj = Quadrature()
        end
    end
    methods (Abstract)
        [val,obj] = next(obj)
    end
end