classdef Midexp < NumericalRecipes.Midpnt
    % Class implementing the extended midpoint rule.
    % This routine is an exact replacement for Midpnt except that bb is
    % assumed to be infinite (value passed is not actually used).  It is
    % assumed that the function funk decreases exponentially rapidly at
    % infinity.
    %
    % Construct with the function to be integrated and the limits of
    % integration.  The function can either be a MATLAB function handle
    % or a NumericalRecipes 'Functor'.  Successive calls to next return
    % increasingly refined results for the integral.
    %
    %  int_class = NumercialRecipes.Midpnt(@(x) f(x),a,b); % Anonymous f(x)
    %         or = NumercialRecipes.Midpnt(@func,a,b);
    %         or = NumercialRecipes.Midpnt(Functor,a,b);
    %     
    methods
        function obj = Midexp(funcc,aa,bb)
            obj = obj@NumericalRecipes.Midpnt(funcc,0,exp(-aa));
        end
        function val = func(obj,x)
            val = obj.funk(-log(x))/x;
        end
    end
end