classdef Normaldev < NumericalRecipes.Ran
    % Class implementing normal deviates
    %
    % Construct with gaussian parameters mu, sig, and a seed
    %   rand_obj = NumericalRecipes.Normaldev(mu,sig,seed)
    % Usage:
    %   rand_obj.dev() returns a random double precission number that is a
    %   random deviate from the Normal distribution 
    %               1/(sig*sqrt(2*pi))*exp(-(x-mu)^2/(2*sig^2))
    %
    properties
        mu
        sig
    end
    methods
        function obj = Normaldev(mu,sig,i)
            obj = obj@NumericalRecipes.Ran(i);
            obj.mu = mu;
            obj.sig = sig;
        end
        function val = dev(obj)
            while(true)
                u = obj.doub();
                v = 1.7156*(obj.doub() - 0.5);
                x = u - 0.449871;
                y = abs(v) + 0.386595;
                q = x*x + y*(0.19600*y - 0.25472*x);
                if q <= 0.27597
                    break
                elseif (q <= 0.27646) && (v*v <= -4.0*log(u)*u*u)
                    break
                end
            end
            val = obj.mu + obj.sig*v/u;
        end
    end
end