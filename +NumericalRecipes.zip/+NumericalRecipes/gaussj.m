function [a,b] = gaussj(a,b)
    % Linear equation solution by Gauss-Jordan elimination.
    %
    % The matrix a is inverted and used to find the solution to a list of
    % right-hand-side vectors stored in b.
    % INPUT
    % a is an array of dimension(n,n).  b is an array of dimensions(n,m).
    % OUTPUT
    % a is replaced by its matrix inverse, and b is replaced by
    % the corresponding set of solution vectors.
    %
    n = length(a);
    if nargin == 1, b = zeros(n,1);  end
    ipiv = int32(zeros(n,1));
    indxr = int32(zeros(n,1));
    indxc = int32(zeros(n,1));
    for i=1:n
        big = 0.0;
        for j=1:n
            if ipiv(j) ~= 1
                for k=1:n
                    if ipiv(k)==0
                        if abs(a(j,k)) >= big
                            big = abs(a(j,k));
                            irow = j;
                            icol = k;
                        end
                    end
                end
            end
        end
        ipiv(icol) = ipiv(icol) + 1;
        if irow ~= icol
            tmp = a(irow,:);
            a(irow,:) = a(icol,:);
            a(icol,:) = tmp;
            tmp = b(irow,:);
            b(irow,:) = b(icol,:);
            b(icol,:) = tmp;
        end
        indxr(i) = irow;
        indxc(i) = icol;
        if a(icol,icol) == 0.0
            throw(MException('NumericalRecipes:gaussj','Singular Matrix'));
        end
        pivinv = 1.0/a(icol,icol);
        a(icol,icol)=1.0;
        a(icol,:) = a(icol,:)*pivinv;
        b(icol,:) = b(icol,:)*pivinv;
        for ll=1:n
            if ll ~= icol
                dum = a(ll,icol);
                a(ll,icol) = 0.0;
                a(ll,:) = a(ll,:) - a(icol,:)*dum;
                b(ll,:) = b(ll,:) - b(icol,:)*dum;
            end
        end
    end
    for l=n:-1:1
        if indxr(l) ~= indxc(l);
            tmp = a(:,indxr(l));
            a(:,indxr(l)) = a(:,indxc(l));
            a(:,indxc(l)) = tmp;
        end
    end
end