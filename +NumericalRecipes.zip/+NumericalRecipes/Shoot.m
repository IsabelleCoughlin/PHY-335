classdef Shoot < NumericalRecipes.Functor
    % Functor for use with "newt" to solve a two-point boundary value
    % problem for a set of ODEs using the shooting method.  
    % The coupled ODEs are integrated from x1 to x2 with initial values for
    % the ODE variables supplied at x1.  Some number of initial values, n1,
    % are known at x1, while n2 values are known at x2, and n1+n2 is the
    % total number of coupled ODEs.  The initial values at x1 are
    % constructed based on the n1 known values and n2 parameters which must
    % be determined.
    %
    % Construct with the start and end points, a class derived from
    % NumericalRecipes.FunctorShoot to load initial values, a class derived
    % from NumericalRecipes.FunctorODE to supply the set of ODEs to be
    % integrated, and a class derived from NumericalRecipes.FunctorShoot to
    % return a vector of scores which should be zero when the boundary
    % conditions at the end are satisfied.
    %
    %    x1 = starting point of integration;
    %    x2 = ending point of integration;
    %    load_obj = NumericalRecipes.FunctorShoot_obj(...);
    %    deriv_obj = NumericalRecipes.FunctorODE_obj(...);
    %    score_obj = NumericalRecipes.FunctorShoot_obj(...);
    %    Shoot_obj =
    %            NumericalRecipes.Shoot(x1,x2,load_obj,deriv_obj,score_obj)
    %
    % The Shoot object is passed to NumercialRecipes.newt as the vecfunc
    % argument.
    %
    properties
        atol = 1.e-8;
        rtol = 1.e-8;
        hmin = 0.0;
        x1
        x2
        load
        d
        score
    end
    methods
        function obj = Shoot(x1,x2,load,derivs,score)
            obj.x1 = x1;
            obj.x2 = x2;
            obj.load = @load.vector;
            obj.d = derivs;
            obj.score = @score.vector;
        end
        function derivs = func(obj,v)
            h1 = (obj.x2 - obj.x1)/100.0;
            y = obj.load(obj.x1,v);
            out = NumericalRecipes.Output(0);
            integ = NumericalRecipes.Odeint(NumericalRecipes.StepperDopr5(),y,obj.x1,obj.x2,obj.atol,obj.rtol,h1,obj.hmin,out,obj.d);
            y = integ.integrate();
            derivs = obj.score(obj.x2,y);
        end
    end
end